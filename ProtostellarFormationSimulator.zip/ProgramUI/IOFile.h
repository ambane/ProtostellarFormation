#ifndef included_IOFile
#define included_IOFile

#include "Particle.h"
#include "IOFile.h"
#include "IOConstants.h"
#include "ParticleArray.h"
#include <stdlib.h>
#include <fstream>
using namespace std;

// Pre:
// Post:
void writeFile (const char * fileName, int numParticles, double massParticles,
                int radius, int maxVelocity, long long spaceSize);

void readFile (const char * fileName, ParticleArray * particleArray,
               int & numParticles, long long & spaceSize);

#endif
