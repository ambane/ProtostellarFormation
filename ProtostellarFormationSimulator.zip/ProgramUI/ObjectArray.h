#ifndef included_ObjectArray
#define included_ObjectArray

#include <iostream>
using namespace std;

template <class T>

class ObjectArray {
  // CI: This object an int called arraySize specifying the size of the array,
  //      an int called numElements specifying the number of elements in the
  //      array, and an array of type T called arrayPointer.
  //     T should be a pointer to an object.

 protected:

  int arraySize;
  int numElements;
  T * arrayPointer;

  
  // Pre:  This object is a defined objectArray object
  // Post: arraySize has been doubled and a new array has been made of
  //        size arraySize
  void doubleArraySize() {
    arraySize *= 2;
    T * copyArray = new T[arraySize];
    for (int index = 0; index < numElements; index ++) {
      copyArray[index] = arrayPointer[index];
    }
    delete [] arrayPointer;
    arrayPointer = copyArray;
  }

  // Pre:  This object is a defined ObjectArray object
  //       pIndex is an integer < numElements
  // Post: The object at index has been deleted and all remaining objects
  //        have been moved down the array
  void deleteHelper(int pIndex) {
    for (int index = pIndex; index + 1 < numElements; index ++) {
      arrayPointer[index] = arrayPointer[index + 1];
    }
    numElements --;
  }
  
 public:

  // Pre:
  // Post: arraySize = 1, numElements = 0, and arrayPointer[0] is the EOS char
  ObjectArray<T> () {
    arraySize = 1;
    numElements = 0;
    arrayPointer = new T[arraySize];
  }

  // Pre:  This object is a defined ObjectArray object
  //       pArray is a defined ObjectArray object
  // Post: This object is a deep copy of pArray
  ObjectArray<T> (const ObjectArray<T> & pArray) {
    arraySize = pArray.arraySize;
    numElements = pArray.numElements;
    arrayPointer = new T[arraySize];
    for (int index = 0; index < numElements; index ++) {
      arrayPointer[index] = pArray.arrayPointer[index];
    }
  }

  // Pre:  This object is a defined ObjectArray object
  // Post: All allocated heap space has been deallocated, all ints are 0
  ~ObjectArray<T> () {
    delete [] arrayPointer;
    arrayPointer = NULL;
    numElements = 0;
    arraySize = 0;
  }

  // Pre:  This object is a defined ObjectArray object
  //       pObject is a pointer to a defined T object
  // Post: pObject has been added to arrayPointer, numElements has been
  //        incremented by one, and arraySize has been doubled if necessary
  void addObject (T pObject) {
    if (numElements == arraySize) {
      doubleArraySize();
    }
    arrayPointer[numElements] = pObject;
    numElements ++;
  }

  // Pre:  This object is a defined ObjectArray object
  //       pObject is a defined T object
  //       pIndex is an integer 0 <= i <= numElements
  // Post: pObject has been added to arrayPointer at pIndex, numElements has
  //        been incremented
  void addObjectToIndex(T pObject, int pIndex) {
    if (pIndex == numElements) {
      addObject(pObject);
    }
    else {
      if (numElements == arraySize) {
	doubleArraySize();
      }
      numElements ++;
      int index = pIndex + 1;
      T temp1 = arrayPointer[pIndex];
      T temp2;
      arrayPointer[pIndex] = pObject;
      while (index < numElements) {
	if (index + 1 != numElements) {
	  temp2 = arrayPointer[index];
	}
	arrayPointer[index] = temp1;
	index ++;
	temp1 = temp2;
      }
    }
  }

  // Pre:  This object is a defined ObjectArray object
  // Post: RV = numElements
  int getNumElements() const {
    return(numElements);
  }

  // Pre:  This object is a defined ObjectArray object
  //       index is an int 0 <= n < numElements
  // Post: RV = arrayPointer[index]
  T getIthObject(int index) const {
    return(arrayPointer[index]);
  }

  // Pre:  This object is a defined ObjectArray object
  //       pData is an object of type T that is in the array
  // Post: RV = the index of pData in arrayPointer
  int findData(const T & pData) const {
    int index = 0;
    while (!(arrayPointer[index] == pData) && (index < numElements)) {
      index ++;
    }
    return(index);
  }

  // Pre:  This object is a defined ObjectArray object
  //       pData is an object of type T
  // Post: pData has been removed from the array and all other data has
  //        been moved down the array
  void deleteData(T pData) {
    int index = findData(pData);
    deleteHelper(index);
  }

  // Pre:  This object is a defined ObjectArray object
  //       pIndex is an integer
  // Post: The data at arrayPointer[pIndex] has been deleted and
  //        all remaining data has been moved down the array
  void deleteByIndex(int pIndex) {
    deleteHelper(pIndex);
  }

  // Pre:  This object is a defined ObjectArray object
  //       pArray is a defined objectArray Object
  // Post: This object is a deep copy of pArray
  ObjectArray<T> operator = (const ObjectArray<T> & pArray) {
    arraySize = pArray.arraySize;
    numElements = pArray.numElements;
    delete [] arrayPointer;
    arrayPointer = new T[arraySize];
    for (int index = 0; index < numElements; index ++) {
      arrayPointer[index] = pArray.arrayPointer[index];
    }
    return(*this);
  }

  // Pre:  stream is a defined ostream object
  //       pArray is a defined ObjectArray object passed by reference as a const
  // Post: RV = stream and stream contains the objects contained in pArray
  friend ostream & operator << (ostream & stream,
				const ObjectArray<T> & pArray) {
    for (int index = 0; index < pArray.numElements; index ++) {
      stream << pArray.arrayPointer[index] << endl;
    }
    return(stream);
  }

};

#endif
