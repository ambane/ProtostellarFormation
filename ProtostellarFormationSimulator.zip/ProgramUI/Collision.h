#ifndef included_Collision
#define included_Collision

#include "ParticleArray.h"
#include "ObjectArray.h"
#include "Particle.h"
#include "Vector.h"
#include "Pair.h"
#include "LineSegment.h"
#include "Octree.h"
#include "OctNode.h"

// Pre:  particleArray is an objectArray<Particle*> passed by ref as a const
//       segmentArray is an objectArray<LineSegment*> passed by reference
// Post: For every particle in particleArray, a LineSegment * object has
//        been created with points representing the starting and ending position
//        of the Particle for the timestep
void createSegmentArray (ParticleArray * particleArray,
			 ObjectArray<LineSegment> & segmentArray);

// Pre:  segmentArray is an objectArray<LineSegment*> passed by reference
//       intersectArray is an objectArray<Pair<Particle*, Particle*> > passed
//        by reference
//       ParticleArray is an objectArray<Particle*> object passed by reference
// Post: Every LineSegment in segmentArray has been compared to every other
//        LineSegment to find any intersection. If they intersect, the
//        respective Particle objects represented by the LineSegment objects
//        have been added to intersectArray
void createIntersectArray (const ObjectArray<LineSegment> & segmentArray,
			   ObjectArray<Pair<Pair<Particle*, Particle*>,
               Vector<unsigned long long, unsigned long long, unsigned long long> > > & intersectArray,
			   ParticleArray * particleArray);

// Pre:  particle1 and particle2 are pointers to Particle objects
//       intersection is a Vector<float, float, float> object
// Post: RV = true iff the particle1 and particle2 are within the radius
//            of the other at the same time
bool determineTime (const Particle * particle1, const Particle * particle2,
            const Vector<unsigned long long, unsigned long long, unsigned long long> &intersection);

// Pre:  intersectArray is an ObjectArray<Pair> object passed by reference
//        where the Pair is a Pair of Particle * and a
//        Vector<float, float, float> representing the point of intersection
//        between the line segments of the pair of particles.
//       timeArray is an ObjectArray<int> object passed by reference
// Post: intersectArray contains the pairs of Particles that reach the
//        point of intersection at the same time and timeArray contains
//        the time they meet.
void findCollisions (ObjectArray<Pair<Pair<Particle *, Particle *>, Vector<unsigned long long, unsigned long long, unsigned long long> > > &intersectArray,
             ObjectArray<Pair<Pair<Particle*, Particle*>, int> > &
             collisions);

// Pre:  particleArray is a ParticleArray object passed by pointer
// Post: Any particles within DISTANCE radii of each other have been
//        combined
void conglomerate(ParticleArray * particleArray, int & numCollisions, int mergeFactor, ofstream & collisionLocation);

// Pre:  particleArray is a ParticleArray object passed by pointer
// Post: All collisions occuring during the timestep have been found and
//        processed
void runCollisions(ParticleArray * particleArray, int & numCollisions, int mergeFactor, ofstream & collisionLocation);

#endif
