#include "animationwindow.h"
#include "ui_animationwindow.h"
#include "Pair.h"
#include "ObjectArray.h"
#include <QPainter>
#include <QPaintEvent>
#include <QPoint>
#include <QInputDialog>
#include <QDir>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include "animationconstants.h"
#include "animationblock.h"
#include "ParticleArray.h"
#include "Particle.h"
#include "ntree.h"
#include "ntreenode.h"
#include "IOFile.h"
using namespace std;

AnimationWindow::AnimationWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AnimationWindow)
{
    construction = true;
    pointArray = new ObjectArray<AnimationParticle*>();
    clusterArray = new ObjectArray<Pair<QRect*, int>* >();
    ui->setupUi(this);
}

AnimationWindow::~AnimationWindow()
{
    delete ui;
    delete pointArray;
    delete clusterArray;
}

void AnimationWindow::runAnimation(const char * fileName, int numFiles, int numDivisions) {
    construction = false;
    int numParticles;
    ParticleArray * elements = new ParticleArray();
    readFile(fileName, elements, numParticles, spaceSize);
    NTree animationTree(numDivisions, spaceSize, elements);
    currNode = animationTree.getRoot();
    createClusterArray();
    cluster = true;
    update();
    sleep(6000);
}

void AnimationWindow::mousePressEvent(QMouseEvent *event) {
    Qt::MouseButton button = event->button();
    if (button == Qt::LeftButton) {
        int xLoc = event->x();
        int yLoc = event->y();
        currNode = currNode->getChild(xLoc, yLoc);
        currNode->divideSpace();
        NTreeNode * tempNode = currNode->getChild(0);
        if (tempNode->getSize() / 2 <= tempNode->getLargeRadius()) {
            createPointArray(currNode->getElements());
            cluster = false;
        }
        else {
            createClusterArray();
            cluster = true;
        }
    }
    else if (button == Qt::RightButton) {
        currNode = currNode->getParent();
        NTreeNode * tempNode = currNode->getChild(0);
        if (tempNode->getSize() / 2 <= tempNode->getLargeRadius()) {
            createPointArray(currNode->getElements());
            cluster = false;
        }
        else {
            createClusterArray();
            cluster = true;
        }
    }
}

void AnimationWindow::paintEvent(QPaintEvent * event) {
        QPainter painter(this);
        painter.setBrush(Qt::red);
        if (cluster) {
            QColor color;
            QRect * rectangle;
            int mass;
            int grad;
            for (int index = 0; index < clusterArray->getNumElements(); index++) {
                rectangle = clusterArray->getIthObject(index)->getFirst();
                mass = clusterArray->getIthObject(index)->getSecond();
                grad = mass % ALPHA;
                color.setRgb(0, 0, grad);
                painter.drawRect(*rectangle);
            }
        }
        else {
            QPoint point;
            int radius;
            for (int index = 0; index < pointArray->getNumElements(); index ++) {
                point = pointArray->getIthObject(index)->getPoint();
                radius = pointArray->getIthObject(index)->getRadius();
                painter.drawEllipse(point, radius, radius);
            }
        }
}

void AnimationWindow::createClusterArray() {
    int numChildren = pow(currNode->getNumDivisions(), 2);
    NTreeNode * tempNode;
    Vector<long long, long long, long long> * point;
    int xLoc;
    int yLoc;
    int size;
    for (int index = 0; index < numChildren; index ++) {
        tempNode = currNode->getChild(index);
        point = tempNode->getPoint();
        xLoc = point->getX() / WINDOW_SIZE;
        yLoc = point->getY() / WINDOW_SIZE;
        size = tempNode->getSize() / WINDOW_SIZE;
        QRect * newRect = new QRect(xLoc, yLoc, size, size);
        Pair<QRect *, int> * newCluster = new Pair<QRect*, int>(newRect, tempNode->getMass());
        clusterArray->addObject(newCluster);
    }
}

void AnimationWindow::createPointArray(ParticleArray * elements) {
    long long xPos;
    long long yPos;
    long long zPos;
    int radius;
    int zShift;
    int xLoc;
    int yLoc;
    double pointShift = WINDOW_SIZE / spaceSize;
    Particle * currNode;
    for (int index = 0; index < elements->getNumElements(); index ++) {
        currNode = elements->getIthObject(index);
        xPos = currNode->getPosition()->getX();
        yPos = currNode->getPosition()->getY();
        zPos = currNode->getPosition()->getZ();
        radius = currNode->getRadius();
        zShift = (zPos * pointShift) * .33;
        xLoc = (xPos * pointShift) + zShift;
        yLoc = (yPos * pointShift) + zShift;
        AnimationParticle * newParticle = new AnimationParticle(radius, xLoc, yLoc);
        pointArray->addObject(newParticle);
    }
}
