#ifndef HELPER_H
#define HELPER_H

#include <string>

std::string intToChar(int number);

#endif // HELPER_H

