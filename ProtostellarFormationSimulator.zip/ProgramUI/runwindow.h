#ifndef RUNWINDOW_H
#define RUNWINDOW_H

#include <QWidget>

namespace Ui {
class RunWindow;
}

class RunWindow : public QWidget
{
    Q_OBJECT

public:
    explicit RunWindow(QWidget *parent = 0);
    ~RunWindow();
    int getNumTimestepsRun() {return(numTimestepsRun);};
    bool getOK() {return(ok);};

private:
    Ui::RunWindow *ui;
    int numTimesteps;
    double timestep;
    int minParticles;
    int minLength;
    int stepsBetweenWrite;
    int mergeFactor;
    bool writeParticles;
    std::string file;
    std::string path;
    std::string fileWithPath;
    std::string particle;
    std::string location;
    std::string collision;
    std::string escaped;
    std::string time;
    int numTimestepsRun;
    bool ok;
    void getPath(const std::string & fileWithPath, std::string & fileName,
                 std::string & filePath);
    void process();


private slots:
    void handleOK();

};

#endif // RUNWINDOW_H
