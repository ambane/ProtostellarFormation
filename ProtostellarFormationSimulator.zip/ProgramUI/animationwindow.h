#ifndef ANIMATIONWINDOW_H
#define ANIMATIONWINDOW_H

#include <QWidget>
#include <QPoint>
#include <QRect>
#include "ObjectArray.h"
#include "animationparticle.h"
#include "animationconstants.h"
#include "ntree.h"
#include "ntreenode.h"
#include "ParticleArray.h"
#include "Pair.h"

namespace Ui {
class AnimationWindow;
}

class AnimationWindow : public QWidget
{
    Q_OBJECT

public:
    explicit AnimationWindow(QWidget *parent = 0);
    ~AnimationWindow();
    void runAnimation(const char *fileName, int numFiles, int numDivisions);
    void paintEvent(QPaintEvent * event);
    void mousePressEvent(QMouseEvent * event);

private:
    Ui::AnimationWindow *ui;
    ObjectArray<AnimationParticle*> * pointArray;
    ObjectArray<Pair<QRect*, int>* > * clusterArray;
    NTreeNode * currNode;
    long long spaceSize;
    bool construction;
    bool cluster;
    void createPointArray(ParticleArray * elements);
    void createClusterArray();

};

#endif // ANIMATIONWINDOW_H
