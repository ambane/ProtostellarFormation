#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "generatewindow.h"
#include "runwindow.h"
#include "animationwindow.h"
#include "progresswindow.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    GenerateWindow * generate;
    RunWindow * run;
    AnimationWindow * animation;
    ProgressWindow * progress;

private slots:
    void handleGenerateFileButton();
    void handleRunSimulationButton();
    void handleWatchSimulationButton();
};

#endif // MAINWINDOW_H
