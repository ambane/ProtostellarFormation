#include "OctNode.h"
#include "OctreeConstants.h"
#include "Vector.h"
#include "ParticleArray.h"
#include "Particle.h"
#include <iostream>
#include <math.h>
using namespace std;

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// CONSTRUCTORS
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

// Pre:
// Post: This object is an OctNode object
//        parent is NULL
//        children[0-8] are NULL
//        coordinate is <0, 0, 0>
//        centerOfMass is <0, 0, 0>
//        massSum is 0
//        length = 0
//        numChildren = 0
//        numElements is 0
OctNode::OctNode () {
  parent = NULL;
  for (int index = 0; index < OCT; index ++) {
    children[index] = NULL;
  }
  elements = new ParticleArray();
  coordinate = new Vector<long long, long long, long long>();
  center = new Vector<long long, long long, long long>();
  centerOfMass = new Vector<long long, long long, long long>();
  massSum = 0;
  length = 0;
  numChildren = 0;
  numElements = 0;
}

// Pre:  pParent is a pointer to an OctNode object
// Post: parent = pParent
//       children[0-8] are NULL
//       coordinate is <0, 0, 0>
//       centerOfMass is <0, 0, 0>
//       massSum is 0
//       length = 0
//       numChildren = 0
//       numElements is 0
OctNode::OctNode (OctNode * pParent) {
  parent = pParent;
  for (int index = 0; index < OCT; index ++) {
    children[index] = NULL;
  }
  elements = new ParticleArray();
  coordinate = new Vector<long long, long long, long long>();
  center = new Vector<long long, long long, long long>();
  centerOfMass = new Vector<long long, long long, long long>();
  massSum = 0;
  length = 0;
  numChildren = 0;
  numElements = 0;
}

// Pre:  This constructor should only be used for the root of the tree.
//       pLength is a long long representing the length of one side of the cube
//        contained in this node
//       pNumElements is an int representing the number of objects contained
//        in the space in this object
//       pElements is a pointer to an objectArray<Particle*> object
// Post: length = pLength
//       numElements = pNumElements
//       elements = pElements
OctNode::OctNode (long long pLength, int pNumElements,
		  ParticleArray * pElements) {
  parent = NULL;
  for (int index = 0; index < OCT; index ++) {
    children[index] = NULL;
  }
  coordinate = new Vector<long long, long long, long long>();
  center = new Vector<long long, long long, long long> ();
  centerOfMass = new Vector<long long, long long, long long>();
  findCenterOfMass(*pElements);
  length = pLength;
  numElements =  pNumElements;
  numChildren = 0;
  elements = pElements;
}

// Pre:  This object is a defined OctNode object
// Post: All heap memory has been deallocated
OctNode::~OctNode () {
  if (children[0] != NULL) {
    for (int index = 0; index < OCT; index ++) {
      delete(children[index]);
    }
  }
  parent = NULL;
  delete(parent);
  elements->AllNull();
  delete(elements);
  delete (coordinate);
  delete (center);
  delete (centerOfMass);
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// GETTERS
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

// Pre:  This object is a defined OctNode object
// Post: RV = coordinate
Vector<long long, long long, long long> * OctNode::getCoordinate () const {
  return(coordinate);
}

// Pre:  This object is a defined OctNode object
// Post: RV = numChildren
int OctNode::getNumChildren() const {
  return(numChildren);
}

// Pre:  This object is a defined OctNode object
// Post: RV = numElements
int OctNode::getNumElements() const {
  return(numElements);
}

// Pre:  This object is a defined OctNode object
// Post: RV = the pointer to the OctNode parent of this object
OctNode * OctNode::getParent() const {
  return(parent);
}

// Pre:  This object is a defined OctNode object
//       index is an integer
// Post: RV = a pointer to the OctNode child at children[index]
OctNode * OctNode::getIthChild(int index) const {
  return(children[index]);
}

// Pre:  This object is a defined OctNode object
// Post: RV = length
long long OctNode::getLength() const {
  return(length);
}

// Pre:  This object is a defined OctNode object
// Post: RV = centerOfMass
Vector<long long, long long, long long> * OctNode::getCenterOfMass () const {
  return(centerOfMass);
}

// Pre:  This object is a defined OctNode object
// Post: RV = massSum
float OctNode::getMass () const {
  return(massSum);
}

// Pre:  This object is a defined OctNode object
// Post: RV = elements
ParticleArray * OctNode::getElements () const {
  return(elements);
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// SETTERS
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

// Pre:  This object is a defined OctNode object
//       pElements is an objectArray<Particle *> 
//       centerOfMass is a Vector<long long, long long, long long> passed as a pointer
//       massSum is a float passed by reference
// Post: centerOfMass is the center of mass of the objects in pElements
//       massSum is the sum of the masses of the objects in pElements
void OctNode::findCenterOfMass(const ParticleArray & pElements) {
  long long x_coord = 0;
  long long y_coord = 0;
  long long z_coord = 0;
  Vector<long long, long long, long long> * position;
  float mass;
  Particle * currObject;
  for (int index = 0; index < pElements.getNumElements(); index ++) {
    currObject = pElements.getIthObject(index);
    mass = currObject->getMass();
    position = currObject->getPosition();
    massSum += mass;
    x_coord += (mass * position->getX());
    y_coord += (mass * position->getY());
    z_coord += (mass * position->getZ());
  }
  x_coord /= massSum;
  y_coord /= massSum;
  z_coord /= massSum;
  centerOfMass->setCoordinates(x_coord, y_coord, z_coord);
}

// Pre:  This object is a defined OctNode object
//       pLength is a long long object
// Post: length = pLength
void OctNode::setLength(long long pLength) {
  length = pLength;
}

// Pre:  This object is a defined OctNode object
//       pNode is a pointer to a defined OctNode object
//       index is an integer 0 <= n < OCT
// Post: children[index] = pNode
void OctNode::setIthChild(OctNode * pNode, int index) {
  children[index] = pNode;
}

// Pre:  This object is a defined OctNode object
//       pNode is a pointer to a defined OctNode object
// Post: parent = pNode
void OctNode::setParent(OctNode * pNode) {
  parent = pNode;
}

// Pre:  This object is a defined OctNode object
//       pInt is an integer
// Post: numElements = pInt
void OctNode::setNumElements(int pInt) {
  numElements = pInt;
}

// Pre:  This object is a defined OctNode object
//       pInt is an integer 0 <= n < OCT
// Post: numChildren = pInt
void OctNode::setNumChildren(int pInt) {
  numChildren = pInt;
}

// Pre:  This object is a defined OctNode object
//       pCoord is a defined Vector object
// Post: coordinate = pCoord
void OctNode::setCoordinate(Vector<long long, long long, long long> * pCoord) {
  coordinate = pCoord;
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// HELPERS
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
  
// Pre:  This object is a defined OctNode object
// Post: The space contained in this object has been divided into octants
//        numElements = 8
void OctNode::divideSpace() {
  float octLength = length / 2;
  float midLength = octLength / 2;
  Vector<long long, long long, long long> position = *coordinate;
  Vector<long long, long long, long long> coordinateVector;
  for (int count = 0; count < OCT; count ++) {
    OctNode * newNode = new OctNode(this);
    coordinateVector.setCoordinates(UNIT_VECTORS[count][0],
				     UNIT_VECTORS[count][1],
				     UNIT_VECTORS[count][2]);
    coordinateVector = (coordinateVector * octLength);
    coordinateVector = (coordinateVector + position);
    newNode->length = octLength;
    *newNode->coordinate = coordinateVector;
    *newNode->center = (coordinateVector + midLength);
    children[count] = newNode;
  }
  numChildren = OCT;
}

// Pre:  This object is a defined OctNode object
// Post: The Particles have been assigned to the children
void OctNode::assignParticles() {
  Particle * currParticle;
  OctNode * currNode;
  Vector<long long, long long, long long> currPosition;
  for (int index = 0; index < numElements; index ++) {
    currParticle = elements->getIthObject(index);
    currPosition = *currParticle->getPosition();
    currNode = children[0];
    long long minDistance = currNode->center->findDistance(currPosition);
    int minDistanceChildIndex = 0;
    long long currDistance;
    for (int childIndex = 1; childIndex < OCT; childIndex ++) {
      currNode = children[childIndex];
      currDistance = currNode->center->findDistance(currPosition);
      if (currDistance < minDistance) {
	minDistance = currDistance;
	minDistanceChildIndex = childIndex;
      }
    }
    currNode = children[minDistanceChildIndex];
    currNode->elements->addObject(currParticle);
    currNode->numElements ++;
  }
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// OPERATORS
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

// Pre:  stream is a defined ostream object passed by reference
//       pNode is an OctNode<T> object passed as a const by reference
// Post: RV = stream and stream contains the data from pNode
ostream & operator << (ostream & stream, const OctNode & pNode) {
  stream << "Length: " << pNode.length << endl;
  stream << "Number of Elements: " << pNode.numElements << endl;
  stream << "Number of Children: " << pNode.numChildren << endl;
  stream << "Origin Coordinate: " << *(pNode.coordinate);
  stream << "Center: " << *pNode.center << endl;
  stream << "Center of Mass: " << *(pNode.centerOfMass);
  stream << "Mass Sum: " << pNode.massSum <<  endl;
  stream << "Elements: " << endl << *pNode.elements << endl;
  return(stream);
}
