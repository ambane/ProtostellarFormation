#ifndef included_CollisionConstants
#define included_CollisionConstants

#define CONVERGE_LENGTH 3
#define MOD_TIME_VAL .01

#endif
