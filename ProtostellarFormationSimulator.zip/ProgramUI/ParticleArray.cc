#include "ParticleArray.h"
#include "Particle.h"
#include <iostream>
using namespace std;

// Pre:  This object is a defined ParticleArray object
// Post: All memory has been deallocated
ParticleArray::~ParticleArray() {
  delete [] arrayPointer;
  arrayPointer = NULL;
  numElements = 0;
  arraySize = 0;
}

// Pre:  This object is a defined ParticleArray object
// Post: All pointers in this object are NULL
void ParticleArray::AllNull() {
    for (int index = 0; index < numElements; index ++) {
        arrayPointer[index] = NULL;
    }
}

// Pre:  This object is a defined objectArray object
//       pID is an integer representing the ID of an object in the array
//       the array must be sorted
// Post: RV = the object in the array that has the ID == pID
Particle * ParticleArray::searchWithID(int pID) {
  Particle * returnObject;
  int index = numElements / 2;
  bool isFound = false;
  while ((!isFound) && (index < numElements)) {
    if (*arrayPointer[index] == pID) {
      returnObject = arrayPointer[index];
      isFound = true;
    }
    else if (*arrayPointer[index] > pID) {
      index = index / 2;
    }
    else {
      if (index <= 1) {
	index ++;
      }
      else {
	index += ((numElements - index) / 2);
      }
    } 
  }
  return(returnObject);
}

// Pre:  This object is a defined objectArray object
// Post: All Particles n such that n.isNull = true have been deleted and the
//        array has been adjusted.
void ParticleArray::deleteNullParticles() {
  int nonNullCount = 0;
  for (int nullCountIndex = 0; nullCountIndex < numElements;
       nullCountIndex ++) {
    if (!arrayPointer[nullCountIndex]->getIsNull()) {
      nonNullCount ++;
    }
  }
  Particle ** copyArray = new Particle*[nonNullCount + 1];
  int copyIndex = 0;
  for (int index = 0; index < numElements; index ++) {
    if (!arrayPointer[index]->getIsNull()) {
      copyArray[copyIndex] = arrayPointer[index];
      copyIndex ++;
    }
  }
  delete [] arrayPointer;
  arrayPointer = copyArray;
  numElements = nonNullCount;
}

// Pre:  This object is a defined objectArray object
// Post: All Particles n such that n.isNull = true have been moved to the
//        end of the array
void ParticleArray::moveNullParticles() {
  int swapIndex = numElements - 1;
  findNonNull(swapIndex);
  int currIndex = 0;
  Particle * tempParticle;
  while (currIndex < swapIndex) {
    if (arrayPointer[currIndex]->getIsNull() == true) {
      tempParticle = arrayPointer[currIndex];
      arrayPointer[currIndex] = arrayPointer[swapIndex];
      arrayPointer[swapIndex] = tempParticle;
      currIndex ++;
      findNonNull(swapIndex);
    }
    else {
      currIndex ++;
    }
  }
}

// Pre:  This object is a defined objectArray object
//        pIndex is an int < numElements passed by reference
// Post: pIndex = the index of the first non-null Particle from pIndex
void ParticleArray::findNonNull(int & pIndex) {
  bool isNullParticle = true;
  while ((pIndex >= 0) && (isNullParticle)) {
    if (arrayPointer[pIndex]->getIsNull() == true) {
      pIndex --;
    }
    else {
      isNullParticle = false;
    }
  }
}

// Pre:  This object is a defined objectArray object
// Post: All Particles n have had their positions updated according to
//        their previous positions and their velocities
void ParticleArray::updatePositions() {
  for (int index = 0; index < numElements; index ++) {
    arrayPointer[index]->updatePosition();
  }
}
