#include "animationinput.h"
#include "ui_animationinput.h"
#include "animationwindow.h"

AnimationInput::AnimationInput(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AnimationInput)
{
    ui->setupUi(this);
    animation = new AnimationWindow();
    ok = false;
    connect(ui->ok, SIGNAL(clicked(bool)), this, SLOT(handleOK()));
    connect(ui->cancel, SIGNAL(clicked(bool)), this, SLOT(close()));
}

AnimationInput::~AnimationInput()
{
    delete ui;
    delete animation;
}

void AnimationInput::handleOK() {
    numFiles = ui->numsteps->value();
    path = ui->pathstring->text().toStdString();
    clusterSize = ui->ClusterSize->value();
    ok = true;
    animation->runAnimation(path.data(), numFiles, clusterSize);
}

int AnimationInput::getNumFiles() {
    return(numFiles);
}

std::string AnimationInput::getPath() {
    return(path);
}

bool AnimationInput::getOK() {
    return(ok);
}

int AnimationInput::getClusterSize() {
    return(clusterSize);
}
