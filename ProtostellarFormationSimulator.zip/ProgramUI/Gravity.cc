#include "Gravity.h"
#include "GravityConstants.h"
#include "Particle.h"
#include "ParticleArray.h"
#include "Vector.h"
#include "ObjectArray.h"
#include "Octree.h"
#include "OctNode.h"
#include "Exception.h"
#include <math.h>
#include <iostream>
using namespace std;

// Pre:  particle1 and particle2 are Particle objects passed as consts by
//        reference
// Post: RV = the Vector object that represents the gravitational force
//             of particle2 on particle1 in the x, y, and z-directions.
Vector<long long,long long,long long> getGravitationForce(const Particle & particle1,
						const Particle & particle2) {
  float partMass1 = particle1.getMass();
  float partMass2 = particle2.getMass();
  float massProduct = partMass1 * partMass2;
  long long distance = (particle1.calculateDistance(particle2)) * KILOMETER;
  // massProduct is the product of the two masses and distance is the
  //  magnitude of the distance between the two particles
  Vector<long long, long long,long long> returnForce = (*(particle2.getPosition()) -
					     *(particle1.getPosition()));
  // returnForce = <particle1.x - particle2.x, particle1.y - particle2.y,
  //                particle1.z - particle2.z>
  //             = <x, y, z>.
  // returnForce currently stores the direction vector specifying the
  //  direction of the gravitational force of particle2 on particle1.
  float force = (massProduct * GRAV_CONSTANT) / (pow(distance, 2));
  // See universal law of gravitation.
  returnForce *= force;
  // returnForce = <x * force, y * force, z * force>
  return(returnForce);
}

// Pre:  particleList is an ObjectArray containing pointers to Particle
//        objects
// Post: For all particles in ObjectArray, the gravitational force between
//        every other particle has been calculated and the velocity of the
//        particle has been updated
void cellGravity(ParticleArray * particles, double timestepDuration) {
  
  int numParticles = particles->getNumElements();
  Vector<long long,long long,long long> forceArray[numParticles];
  Particle * currParticle;
  Particle * compareParticle;
  Vector<long long,long long,long long> forceVector;
  Vector<long long,long long,long long> velocityAddition;
  float mass;
  for (int index = 0; index < numParticles; index ++) {
    currParticle = particles->getIthObject(index);
    if (currParticle != NULL) {
      for (int times = index + 1; times < numParticles; times ++) {
	// Compare the current particle to every particle after it in the list.
	compareParticle = particles->getIthObject(times);
	if (compareParticle != NULL) {
	  forceVector = getGravitationForce(*currParticle, *compareParticle);
	  forceArray[index] += forceVector;
	  forceArray[times] += (forceVector * -1);
	  // The gravitational force of particle1 on particle2 is equal in
	  //  magnitude to the force of particle2 on particle1 and opposite in
	  //  direction.
	  mass = currParticle->getMass();
      velocityAddition = (forceArray[index] / mass) * timestepDuration;
	  // Using a = F / m, the acceleration caused by the gravitational force
	  // is calculated. To obtain the total change in velocity, the
	  // acceleration is multiplied by the change in time, or TIMESTEP.
	  currParticle->accelerateParticle(velocityAddition);
	  // ASSERT: The current particle has been accelerated according to
	  //         the gravitational force of every other particle in its
	  //         cell.
	}
	else {
	  throw (Exception((char *)"CompareParticle NULL in Cell Gravity."));
	}
      }
    }
    else {
      throw (Exception((char *)"CurrParticle NULL in Cell Gravity."));
    }
  }
}

// Pre:  cell1 and parent are OctNode<Particle*> objects
//       cellIndex is an integer representing the index of cell1 in the Octants
// Post: The acceleration from the force between the two center of masses
//        has been applied to each particle
void siblingGravity(const OctNode & cell1,
		    int cellIndex,
            const OctNode & parent,
                    double timestepDuration) {
  long long distance;
  float mass;
  Vector<long long,long long,long long> coord1;
  Vector<long long,long long,long long> coord2;
  Vector<long long,long long,long long> directionVector;
  Vector<long long,long long,long long> forceVector;
  float force;
  ParticleArray * particles = cell1.getElements();
  int numParticles = cell1.getNumElements();
  Particle * currParticle;
  Vector<long long,long long,long long> velocityAddition;
  for (int particleIndex = 0; particleIndex < numParticles; particleIndex ++) {
    currParticle = particles->getIthObject(particleIndex);
    if (currParticle != NULL) {
      coord1 = *(currParticle->getPosition());
      // coord1 stores the position vector of the current particle.
      for (int index = 0; index < OCT; index ++) {
	if (index != cellIndex) {
	  // ASSERT: The cell being processed is not the cell in which
	  //          currParticle is located.
	  OctNode * compareNode = parent.getIthChild(index);
	  if (compareNode->getNumElements() != 0) {
	    coord2 = *(compareNode->getCenterOfMass());
	    // coord2 stores the center of mass position vector
	    //  of the current cell.
	    directionVector = coord2 - coord1;
	    // directionVector stores the direction of the cells force on the
	    //  current particle.
	    distance = directionVector.getMagnitude() * KILOMETER;
	    // distance stores the magnitude of the distance between the
	    //  particle and the center of mass of the cell.
	    if (distance != 0) {
	      // ASSERT: The distance between the particle and the center of
	      //          mass of the cell is non-zero.
	      mass = compareNode->getMass();
	      // mass stores the mass sum of all the particles in the
	      //  current cell.
	      force = (GRAV_CONSTANT * mass) / pow(distance, 2);
	      if (force != 0) {
		velocityAddition += (directionVector * force);
		// velocityAddition stores the sum of the acceleration vectors
		// of every cell on the current particle.
	      }
	    }
	  }
	}
      }
      velocityAddition *= timestepDuration;
      // velocityAddition now represents the change in velocity supplied by the
      //  acceleration over TIMESTEP change in time.
      currParticle->accelerateParticle(velocityAddition);
      velocityAddition.setCoordinates(0, 0, 0);
    }
    else {
      throw(Exception((char *)"CurrParticle NULL in SiblingGravity."));
    }
  }
}
