#ifndef included_OctNode
#define included_OctNode

#include <iostream>
#include <math.h>
#include "OctreeConstants.h"
#include "Vector.h"
#include "ParticleArray.h"
#include "Particle.h"
using namespace std;

class OctNode {
  // CI:  This object contains a pointer to its parent OctNode object
  //      This object contains 8 pointers to seperate OctNode children
  //       stored in an array.
  //      All pointers default to NULL.
  //      coordinate is a Vector object representing the coordinate of one
  //       corner of the cube of space contained in this object
  //      centerOfMass is a Vector object representing the coordinate of the
  //       center of mass of the space contained in this object
  //      massSum is a float representing the sum of the mass of all the objects
  //       in this object
  //      numElements is an int representing the number of objects contained
  //       in the space in this object.
  //      length is a floating point value that represents the length of one
  //       edge of the cube of space contained in this object.
  //      numElements is an int representing the number of children this
  //       node contains. numElements is either 0 or 8.
  //      elements is an array of pointers to Particle objects

 private:

  OctNode * parent;
  OctNode * children[OCT];
  long long length;
  Vector<long long,long long,long long> * coordinate;
  Vector<long long,long long,long long> * center;
  Vector<long long,long long,long long> * centerOfMass;
  float massSum;
  int numChildren;
  int numElements;
  ParticleArray * elements;

 public:

  // Pre:
  // Post: This object is an OctNode object
  //        parent is NULL
  //        children[0-8] are NULL
  //        coordinate is <0, 0, 0>
  //        centerOfMass is <0, 0, 0>
  //        massSum is 0
  //        length = 0
  //        numChildren = 0
  //        numElements is 0
  OctNode ();

  // Pre:  pParent is a pointer to an OctNode object
  // Post: parent = pParent
  //       children[0-8] are NULL
  //       coordinate is <0, 0, 0>
  //       centerOfMass is <0, 0, 0>
  //       massSum is 0
  //       length = 0
  //       numChildren = 0
  //       numElements is 0
  OctNode (OctNode * pParent);

  // Pre:  This constructor should only be used for the root of the tree.
  //       pLength is a long long representing the length of one side of the cube
  //        contained in this node
  //       pNumElements is an int representing the number of objects contained
  //        in the space in this object
  //       pElements is a pointer to an objectArray<Particle*>
  //        that contains pointers to the objects contained in this space
  // Post: length = pLength
  //       numElements = pNumElements
  //       elements = pElements
  OctNode (long long pLength, int pNumElements,
	   ParticleArray * pElements);

  // Pre:  This object is a defined OctNode object
  // Post: All heap memory has been deallocated
  ~OctNode (); 

  // Pre:  This object is a defined OctNode object
  // Post: RV = coordinate
  Vector<long long, long long, long long> * getCoordinate () const;

  // Pre:  This object is a defined OctNode object
  // Post: RV = numChildren
  int getNumChildren() const;

  // Pre:  This object is a defined OctNode object
  // Post: RV = numElements
  int getNumElements() const;

  // Pre:  This object is a defined OctNode object
  // Post: RV = the pointer to the OctNode parent of this object
  OctNode * getParent() const;

  // Pre:  This object is a defined OctNode object
  //       index is an integer
  // Post: RV = a pointer to the OctNode child at children[index]
  OctNode * getIthChild(int index) const;

  // Pre:  This object is a defined OctNode object
  // Post: RV = length
  long long getLength() const;

  // Pre:  This object is a defined OctNode object
  // Post: RV = centerOfMass
  Vector<long long, long long, long long> * getCenterOfMass () const;

  // Pre:  This object is a defined OctNode object
  // Post: RV = massSum
  float getMass () const;

  // Pre:  This object is a defined OctNode object
  // Post: RV = elements
  ParticleArray * getElements () const;

  // Pre:  This object is a defined OctNode object
  //       pElements is an objectArray<Particle*> object
  // Post: centerOfMass is the center of mass of the objects in pElements
  //       massSum is the sum of the masses of the objects in pElements
  void findCenterOfMass(const ParticleArray & pElements);

  // Pre:  This object is a defined OctNode object
  //       pLength is a long long object
  // Post: length = pLength
  void setLength(long long pLength);

  // Pre:  This object is a defined OctNode object
  //       pNode is a pointer to a defined OctNode object
  //       index is an integer 0 <= n < OCT
  // Post: children[index] = pNode
  void setIthChild(OctNode * pNode, int index);

  // Pre:  This object is a defined OctNode object
  //       pNode is a pointer to a defined OctNode object
  // Post: parent = pNode
  void setParent(OctNode * pNode);

  // Pre:  This object is a defined OctNode object
  //       pInt is an integer
  // Post: numElements = pInt
  void setNumElements(int pInt);

  // Pre:  This object is a defined OctNode object
  //       pInt is an integer 0 <= n < OCT
  // Post: numChildren = pInt
  void setNumChildren(int pInt);

  // Pre:  This object is a defined OctNode object
  //       pCoord is a defined Vector object
  // Post: coordinate = pCoord
  void setCoordinate(Vector<long long, long long, long long> * pCoord);
  
  // Pre:  This object is a defined OctNode object
  // Post: The space contained in this object has been divided into octants
  //        numElements = 8
  void divideSpace();

  // Pre:  This object is a defined OctNode object
  // Post: The Particles have been assigned to the children
  void assignParticles();

  // Pre:  stream is a defined ostream object passed by reference
  //       pNode is an OctNode<T> object passed as a const by reference
  // Post: RV = stream and stream contains the data from pNode
  friend ostream & operator << (ostream & stream, const OctNode & pNode);

};

#endif
