#ifndef included_BinaryTree
#define included_BinaryTree

#include "BinaryTreeNode.h"

#include <iostream>
#include <stdlib.h>
using namespace std;

template <class T>
class BinTree {

  // CI: This object represents a rooted, undirected, ordered  binary search
  //      tree. This object will have a BinaryTreeNodepointer to the root
  //      of the binary tree called root and an integer representing the
  //      number of vertices in the tree. Each vertice will have a
  //      left and right child vertex containing integers unless the
  //      vertex is a leaf, in which case each child pointer is NULL.

 protected:

  BinaryTreeNode<T> * root; // a pointer to the first BinaryTreeNode in the tree

  int numElements; // stores the number of vertices in the tree

  // Pre:  This object is a well defined BinTree object
  //       isLeftChild is a bool
  //       leftChild and rightChild are either NULL or BinaryTreeNode<T> object
  //        pointers; exactly one is NULL and one is a BinaryTreeNode<T> object
  //       parent is either a pointer to a BinaryTreeNode<T> object or NULL
  // Post: if parent is NULL, then the non NULL BinaryTreeNode<T>
  //        parameter is the root
  //       else, if isLeftChild is true, then the non NULL BinaryTreeNode<T>
  //        parameter is the leftChild of parent
  //       else, the non NULL BinaryTreeNode<T> parameter is the rightChild
  //        of parent
  void deleteWithOneChild(bool isLeftChild, BinaryTreeNode<T> * leftChild,
			  BinaryTreeNode<T> * rightChild,
			  BinaryTreeNode<T> * parent) {
    if (leftChild == NULL) {
      if (parent != NULL) {
	if (isLeftChild) {
	  parent->setLeftChild(rightChild);
	}
	else {
	  parent->setRightChild(rightChild);
	}
      }
      else {
	root = rightChild;
	rightChild->setParent(NULL);
      }
    }
    else {
      if (parent != NULL) {
	if (isLeftChild) {
	  parent->setLeftChild(leftChild);
	}
	else {
	  parent->setRightChild(leftChild);
	}
      }
      else {
	root = leftChild;
	leftChild->setParent(NULL);
      }
    }
  }

  // Pre:  This object is a well defined BinTree object
  //       isLeftChild is a bool
  //       leftChild, rightChild, and parent are BinaryTreeNode<T> object pointers
  //        parent may be NULL
  // Post: if parent is NULL, then the minimumNode of rightChild is root
  //       else, if isLeftChild is true, the minimumNode of rightChild is
  //             the leftChild of parent
  //             else, the minimumNode of rightChild is the rightChild of
  //                   parent
  void deleteWithTwoChildren(bool isLeftChild, BinaryTreeNode<T> * leftChild,
			     BinaryTreeNode<T> * rightChild,
			     BinaryTreeNode<T> * parent) {
    BinaryTreeNode<T> * minimumNode = findMinimumNode(rightChild);
    BinaryTreeNode<T> * minimumNodeParent = minimumNode->getParent();
    BinaryTreeNode<T> * minimumNodeRightChild = minimumNode->getRightChild();
    minimumNodeParent->setLeftChild(NULL);
    minimumNode->setLeftChild(leftChild);
    minimumNode->setParent(NULL);
    minimumNode->setRightChild(rightChild);
    if (parent != NULL) {	
      if (isLeftChild) {
	parent->setLeftChild(minimumNode);
      }
      else {
	parent->setRightChild(minimumNode);
      }
    }
    else {
      root = minimumNode;
    }
    if (!minimumNode->isLeaf()) {
      minimumNodeParent->setLeftChild(minimumNodeRightChild);
    }
  }
    
  // Pre:  This object is a well defined BinTree object
  //       pRoot is a BinaryTreeNode object passed by reference as a const
  // Post: RV = the height of the tree from pRoot
  int findHeightHelper (const BinaryTreeNode <T> & pRoot) {
    int leftHeight = 0;
    int rightHeight = 0;
    int realHeight = 0;
    if (pRoot->getLeftChild() != NULL) {
      leftHeight = findHeight(*pRoot->getLeftChild());
      leftHeight ++;
    }
    if (pRoot->getRightChild() != NULL) {
      rightHeight = findHeight(*pRoot->getRightChild());
      rightHeight ++;
    }
    if (leftHeight >= rightHeight) {
      realHeight = leftHeight;
    }
    else {
      realHeight = rightHeight;
    }
    return(realHeight);
  }

  // Pre:  This object is a well defined BinTree object
  //       pRoot is a pointer to a BinaryTreeNode object
  // Post: prints the leaves of this object
  void printLeavesHelper (BinaryTreeNode <T> * pRoot) {
    if ((pRoot->getLeftChild() != NULL) || (pRoot->getRightChild() != NULL)) {
      if (pRoot->getLeftChild() != NULL) {
	BinaryTreeNode<T> * leftRoot = pRoot->getLeftChild();
	printLeavesHelper(leftRoot);
      }
      if (pRoot->getRightChild() != NULL) {
	BinaryTreeNode<T> * rightRoot = pRoot->getRightChild();
	printLeavesHelper(rightRoot);
      }
    }
    else {
      cout << *pRoot << endl;
    }
  }

  // Pre:  This object is a well defined BinTree object
  //       pRoot is a pointer to a BinaryTreeNode object
  // Post: prints this object in pre-order traversal
  void printPreOrderHelper (BinaryTreeNode <T> * pRoot) {
    cout << *pRoot << endl;
    if (pRoot->getLeftChild() != NULL) {
      BinaryTreeNode <T> * leftRoot = pRoot->getLeftChild();
      printPreOrderHelper(leftRoot);
    }
    if (pRoot->getRightChild() != NULL) {
      BinaryTreeNode <T> * rightRoot = pRoot->getRightChild();
      printPreOrderHelper(rightRoot);
    }
  }

  // Pre:  This object is a well defined BinTree object
  //       pRoot is a pointer to a BinaryTreeNode object
  // Post: prints this object in in-order traversal
  void printInOrderHelper (BinaryTreeNode <T> * pRoot) {
    if (pRoot->getLeftChild() != NULL) {
      BinaryTreeNode <T> * leftRoot = pRoot->getLeftChild();
      printInOrderHelper(leftRoot);
    }
    cout << *pRoot << endl;
    if (pRoot->getRightChild() != NULL) {
      BinaryTreeNode <T> * rightRoot = pRoot->getRightChild();
      printInOrderHelper(rightRoot);
    }
  }

  // Pre:  This object is a well defined BinTree object
  //       pRoot is a pointer to a BinaryTreeNode object
  // Post: prints this object in in-order traversal
  void printPostOrderHelper (BinaryTreeNode <T> * pRoot) {
    if (pRoot->getLeftChild() != NULL) {
      BinaryTreeNode <T> * leftRoot = pRoot->getLeftChild();
      printPostOrderHelper(leftRoot);
    }
    if (pRoot->getRightChild() != NULL) {
      BinaryTreeNode <T> * rightRoot = pRoot->getRightChild();
      printPostOrderHelper(rightRoot);
    }
    cout << *pRoot << endl;
  }


 public:

  // Pre:
  // Post: root is NULL
  //       numElements = 0
  BinTree () {
    root = NULL;
    numElements = 0;
  }

  // Pre:  pData is an object of type T passed by reference as a const
  // Post: root is a pointer to a BinaryTreeNode containing pData
  //       numElements is 1
  BinTree (const T & pData) {
    root = new BinaryTreeNode<T>(pData);
    numElements = 1;
  }

  // Pre:  This object is a well defined BinTree object
  // Post: All dynamic memory has been deallocated
  //        root is NULL
  //        numElements is 0
  ~BinTree () {
    delete root;
    root = NULL;
    numElements = 0;
  }

////////////////////////////////////////////////////////////////////////////////
// GETTERS
////////////////////////////////////////////////////////////////////////////////

  
  // Pre:  This object is a well defined BinTree object
  // Post: RV = the root of this object
  BinaryTreeNode <T> * getRoot () const {
    return(root);
  }

  // Pre:  This object is a well defined BinTree object
  // Post: RV = numElements
  int getNumElements() const {
    return(numElements);
  }

////////////////////////////////////////////////////////////////////////////////
// HELPERS
////////////////////////////////////////////////////////////////////////////////

  // Pre:  This object is a well defined BinTree object
  //       pData is an object of type T passed by reference as a const
  // Post: pData has been added to the tree
  void addData(const T & pData) {
    BinaryTreeNode<T> * newNode = new BinaryTreeNode<T>(pData);
    BinaryTreeNode<T> * iterate = root;
    if (numElements == 0) {
      root = newNode;
    }
    else {
      bool notPlaced = true;
      while (notPlaced) {
	if (pData <= iterate->getData()) {
	  if (iterate->getLeftChild() != NULL) {
	    iterate = iterate->getLeftChild();
	  }
	  else {
	    iterate->setLeftChild(newNode);
	    notPlaced = false;
	  }
	}
	else {
	  if (iterate->getRightChild() != NULL) {
	    iterate = iterate->getRightChild();
	  }
	  else {
	    iterate->setRightChild(newNode);
	    notPlaced = false;
	  }
	}
      }
    }
    numElements ++;
  }

  // Pre:  This object is a well defined BinTree object
  //       pData is an object of type T passed by reference as a const
  // Post: This object is a well defined BinTree object and the node
  //        containing data == pData has been deleted
  void deleteData (const T & pData) {
    BinaryTreeNode <T> * deleteNode = findNode(pData);
    BinaryTreeNode <T> * leftChild = deleteNode->getLeftChild();
    BinaryTreeNode <T> * rightChild = deleteNode->getRightChild();
    BinaryTreeNode <T> * parent = deleteNode->getParent();
    deleteNode->setPointersNull();
    delete deleteNode;
    bool isLeftChild;
    if (parent != NULL) {
      isLeftChild = (parent->getData() >= pData);
    }
    if ((leftChild == NULL) && (rightChild == NULL)) {
      if (parent != NULL) {
	if (isLeftChild) {
	  parent->setLeftChild(NULL);
	}
	else {
	  parent->setRightChild(NULL);
	}
      }
    }
    else if (((leftChild == NULL) && (rightChild != NULL)) ||
	     ((leftChild != NULL) && (rightChild == NULL))) {
      deleteWithOneChild(isLeftChild, leftChild, rightChild, parent);
    }
    else if ((leftChild != NULL) && (rightChild != NULL)) {
      deleteWithTwoChildren(isLeftChild, leftChild, rightChild, parent);
    }
  }
  
  
  // Pre:  This object is a well defined BinTree object
  //       pData is of type T
  // Post: RV = a pointer to the first BinaryTreeNode object with data == pData
  BinaryTreeNode <T> * findNode (const T & pData) {
    BinaryTreeNode<T> * iterate = root;
    while (iterate->getData() != pData) {
      if (pData < iterate->getData()) {
	iterate = iterate->getLeftChild();
      }
      else {
	iterate = iterate->getRightChild();
      }
    }
    return(iterate);
  }

  // Pre:  This object is a well defined BinTree object
  //       pRoot is a pointer to a BinaryTreeNode object of type T
  // Post: RV = a pointer to the minimum node in this tree
  BinaryTreeNode<T> * findMinimumNode(BinaryTreeNode<T> * pRoot) {
    BinaryTreeNode<T> * returnNode = pRoot;
    while (returnNode->getLeftChild() != NULL) {
      returnNode = returnNode->getLeftChild();
    }
    return(returnNode);
  }

  // Pre:  This object is a well defined BinTree object
  //       pRoot is a pointer to a BinaryTreeNode object of type T
  // Post: RV = a pointer to the maximum node in this tree
  BinaryTreeNode<T> * findMaximumNode(BinaryTreeNode<T> * pRoot) {
    BinaryTreeNode<T> * returnNode = pRoot;
    while (returnNode->getRightChild() != NULL) {
      returnNode = returnNode->getRightChild();
    }
    return(returnNode);
  }

  // Pre:  This object is a well defined BinTree object
  // Post: RV = data from the minimum node in this tree
  T findMinimumData () {
    BinaryTreeNode<T> * iterate = root;
    while (iterate->getLeftChild() != NULL) {
      iterate = iterate->getLeftChild();
    }
    return(iterate->getData());
  }

  // Pre:  This object is a well defined BinTree object
  // Post: RV = data from the maximum node of this tree
  T findMaximumData () {
    BinaryTreeNode<T> * iterate = root;
    while (iterate->getRightChild() != NULL) {
      iterate = iterate->getRightChild();
    }
    return(iterate->getData());
  }

  // Pre:  This object is a well defined BinTree object
  // Post: RV = the height of the tree from pRoot
  int findHeight () {
    findHeightHelper(root);
  }
    
  // Pre:  This object is a well defined BinTree object
  //       pRoot is a pointer to a BinaryTreeNode object
  // Post: RV = the bool stating whether this object is balanced such that
  //        the height of each vertex's children differ in height by
  //        no more than one
  bool isBalanced () {
    int rightHeight = findHeight(root->getRightChild());
    int leftHeight = findHeight(root->getLeftChild());
    return(abs((rightHeight - leftHeight)) <= 1);
  }

////////////////////////////////////////////////////////////////////////////////
// OUTPUT
////////////////////////////////////////////////////////////////////////////////

  // Pre:  This object is a well defined BinTree object
  // Post: The leaves of this tree have been sent to the terminal
  void printLeaves () {
    printLeavesHelper(root);
  }

  // Pre:  This object is a well defined BinTree object
  // Post: The tree has been printed pre order
  void printPreOrder () {
    printPreOrderHelper(root);
  }

  // Pre:  This object is a well defined BinTree object
  // Post: The tree has been printed in order
  void printInOrder () {
    printInOrderHelper(root);
  }

  // Pre:  This object is a well defined BinTree object
  // Post: The tree has been printed post order
  void printPostOrder () {
    printPostOrderHelper(root);
  }
 
};

#endif
