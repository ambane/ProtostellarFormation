#include "ntreenode.h"
#include <math.h>
#include "Particle.h"
#include "animationconstants.h"

NTreeNode::NTreeNode()
{

}

NTreeNode::NTreeNode(int pNumDivisions, int pSize, NTreeNode * pParent,
                     Vector<long long, long long, long long> *pPoint) {
    size = pSize;
    numDivisions = pNumDivisions;
    parent = pParent;
    point = pPoint;
    mass = 0;
}

NTreeNode::NTreeNode(int pNumDivisions, int pSize,
                     Vector<long long, long long, long long> *pPoint,
                     ParticleArray * pElements) {
    numDivisions = pNumDivisions;
    size = pSize;
    elements = pElements;
    point = pPoint;
    parent = NULL;
    for (int index = 0; index < pElements->getNumElements(); index ++) {
        mass += pElements->getIthObject(index)->getMass();
    }
}

void NTreeNode::divideSpace() {
    if (elements->getNumElements() > 0) {
        int numChildren = pow(numDivisions, 2);
        children.resize(numChildren);
        int childIndex = 0;
        float divideSize = size / numDivisions;
        Vector<long long, long long, long long> coordinateVector;
        for (int x = 0; x < numDivisions; x ++) {
            for (int y = 0; y < numDivisions; y ++) {
                coordinateVector.setCoordinates(x * divideSize, y * divideSize, 0);
                Vector<long long, long long, long long> * newPoint =
                        new Vector<long long, long long, long long>(
                            *point + coordinateVector);
                NTreeNode * newNode = new NTreeNode(numDivisions, divideSize, this, newPoint);
                children[childIndex] = newNode;
                childIndex ++;
            }
        }
        assignParticles();
        NTreeNode * currNode;
        for (int index = 0; index < numChildren; index ++) {
            currNode = children[index];
            currNode->setLargeRadius();
        }
    }
}

void NTreeNode::assignParticles() {
    Particle * currParticle;
    NTreeNode * currNode;
    Vector<long long, long long, long long> currPosition;
    int childSize = children[0]->size;
    for (int index = 0; index < elements->getNumElements(); index++) {
        currParticle = elements->getIthObject(index);
        currPosition = *currParticle->getPosition();
        currNode = children[0];
        long long xPos = currPosition.getX();
        long long yPos = currPosition.getY();
        int xVal = xPos / childSize;
        int yVal = yPos / childSize;
        int childIndex = (xVal + (yVal * numDivisions) - 1);
        currNode = children[childIndex];
        currNode->elements->addObject(currParticle);
        currNode->mass += currParticle->getMass();
    }
}

NTreeNode * NTreeNode::getChild(int xLoc, int yLoc) {
    int childSize = WINDOW_SIZE / numDivisions;
    int xVal = xLoc / childSize;
    int yVal = yLoc / childSize;
    int childIndex = (xVal + (yVal * numDivisions) - 1);
    return(children[childIndex]);
}

void NTreeNode::setLargeRadius() {
    Particle * currParticle = elements->getIthObject(0);
    int currSize = currParticle->getRadius();
    for (int index = 1; index < elements->getNumElements(); index ++) {
        currParticle = elements->getIthObject(index);
        if (currParticle->getRadius() > currSize) {
            currSize = currParticle->getRadius();
        }
    }
    largeRadius = currSize;
}

int NTreeNode::getLargeRadius() {
    return(largeRadius);
}

Vector<long long, long long, long long> * NTreeNode::getPoint() {
    return(point);
}

NTreeNode * NTreeNode::getChild(int index) {
    return(children[index]);
}

int NTreeNode::getNumDivisions() {
    return(numDivisions);
}

NTreeNode * NTreeNode::getParent() {
    return(parent);
}

ParticleArray * NTreeNode::getElements() {
    return(elements);
}

int NTreeNode::getMass() {
    return(mass);
}

int NTreeNode::getSize() {
    return(size);
}

std::vector<NTreeNode*> NTreeNode::getChildren() {
    return(children);
}

void NTreeNode::addElement(Particle *pParticle) {
    elements->addObject(pParticle);
}
