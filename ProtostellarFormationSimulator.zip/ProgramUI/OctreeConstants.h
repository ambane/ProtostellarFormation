#ifndef included_OctreeConstants
#define included_OctreeConstants

#define OCT 8
#define TRIPLE 3
#define DIMENSIONS 3

static int UNIT_VECTORS[OCT][DIMENSIONS] = {
  {0, 0, 0},
  {1, 0, 0},
  {0, 1, 0},
  {1, 1, 0},
  {0, 0, 1},
  {1, 0, 1},
  {0, 1, 1},
  {1, 1, 1}
};


#endif
