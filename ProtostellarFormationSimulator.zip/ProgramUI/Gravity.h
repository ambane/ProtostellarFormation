#ifndef included_Gravity
#define included_Gravity

#include "GravityConstants.h"
#include "Particle.h"
#include "Vector.h"
#include "ParticleArray.h"
#include "Octree.h"
#include "OctNode.h"

// Pre:  particle1 and particle2 are Particle objects passed as consts by
//        reference
// Post: RV = the Vector object that represents the gravitational force
//             of particle2 on particle1 in the x, y, and z-directions.
Vector<long long, long long, long long> getGravitationForce(const Particle & particle1,
						const Particle & particle2);

// Pre:  particleList is an ParticleArray containing n pointers to Particle
//        objects
// Post: For all particles in ParticleArray, the gravitational force between
//        every other particle has been calculated and the velocity of the
//        particle has been updated
void cellGravity(ParticleArray * particleArray, double timestepDuration);

// Pre:  cell1 and parent are OctNode<Particle*> objects
//       cellIndex is an integer representing the index of cell1 in the Octants
// Post: The acceleration from the force between the two center of masses
//        has been applied to each particle
void siblingGravity(const OctNode & cell1,
		    int cellIndex,
            const OctNode & parent,
                    double timestepDuration);


#endif
