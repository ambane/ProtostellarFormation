#ifndef included_Pair
#define included_Pair

template <class T1, class T2>
class Pair {

  // CI:  This object contains two objects of type T1 and T2

 private:

  T1 first;
  T2 second;

 public:

  // Pre:
  // Post: This object has been constructed
  Pair<T1, T2>() {};

  // Pre:  pFirst is a defined object of type T1
  //       pSecond is a defined object of type T2
  // Post: first = pFirst and second = pSecond
  Pair<T1, T2>(T1 pFirst, T2 pSecond) {
    first = pFirst;
    second = pSecond;
  }

  // Pre:  This object is a defined Pair object
  // Post: RV = first
  T1 getFirst() const {
    return(first);
  }

  // Pre:  This object is a defined Pair object
  // Post: RV = second
  T2 getSecond() const {
    return(second);
  }

  // Pre:  This object is a defined Pair object
  //       pFirst is a defined object of type T1
  // Post: first = pFirst
  void setFirst(T1 pFirst) {
    first = pFirst;
  }

  // Pre:  This object is a defined Pair object
  //       pSecond is a defined object of type T2
  // Post: second = pSecond
  void setSecond(T2 pSecond) {
    second = pSecond;
  }

  // Pre:  This object is a defined Pair object
  //       pFirst is an object of type T1
  //       pSecond is an object of type T2
  // Post: first = pFirst, second = pSecond
  void setValues(T1 pFirst, T2 pSecond) {
      first = pFirst;
      second = pSecond;
  }

  // Pre:  stream is a defined ostream passed by reference
  //       pPair is a Pair<T1,T2> object
  // Post: RV = stream
  friend ostream & operator << (ostream & stream, const Pair<T1, T2> & pPair) {
      stream << pPair.first << ' ' << pPair.second << ' ';
      return(stream);
  }

};

#endif
  
