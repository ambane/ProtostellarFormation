#ifndef included_Octree
#define included_Octree

#include "OctNode.h"
#include "ParticleArray.h"
#include "Particle.h"
#include <iostream>
using namespace std;

class Octree {
  //CI: This object contains a pointer to an OctNode object that
  //     is the root of the tree.
  //    numElements is an integer representing the number of elements
  //     in the tree
  //    minLength is a floating point value specifying the minimum amount
  //     of space to be contained in a node
  //    minCount is an int specifying the minimum number of objects to be
  //     found in the space contained in a node

 private:

  OctNode * root;
  int numElements;
  float minLength;
  int minCount;

  // Pre:  This object is a defined Octree object
  // Post: The nodes have been sent to the OS in Postorder Traversal
  void postOrderOutputHelper(OctNode * pRoot);

  // Pre:  This object is a defined Octree object
  //       root is a pointer to a defined OctNode object
  //       baseCase is false
  // Post: This object has been created and the space contained in the root
  //        has been recursively divided until the base length or minimum
  //        contained objects was found
  void createTreeHelper(OctNode * pRoot, bool baseCase);

 public:

  // Pre:
  // Post: This object is an Octree object
  //        root has been allocated space on the heap
  //        numElements = 0
  Octree ();
  
  // Pre:  length is a float representing the space contained in this object
  //       pNumElements is the number of elements contained in this object
  //       pElements is the objectArray object containing pointers to the
  //        objects in this space
  //       pMinLength is the minimum length of an octant n such that if the
  //        length of an octant <= n, the octant will not be divided
  //       pMinCount is the minimum number of particles to be in an octant, n
  //        such that if the number of elements in the octant <= n, the
  //        octant will not be divided
  // Post: root is an OctNode pointer containing pLength, pNumElements,
  //        and pElements
  //       numElements = pNumElements
  //       minLength = pMinLength
  //       minCount = pMinCount
  Octree (long long pLength, int pNumElements,
	  ParticleArray * pElements,
	  float pMinLength, int pMinCount);
  
  // Pre:  This object is a defined Octree object
  // Post: All dynamic memory has been deallocated
  //       root is NULL
  //       numElements is 0
  ~Octree ();

  // Pre:  This object is a defined Octree object
  //       pInt is an int
  // Post: numElements = pInt
  void setNumElements(int pInt) {numElements = pInt;};

  // Pre:  This object is a defined Octree object
  // Post: RV = numElements
  int getNumElements() {return(numElements);};

  // Pre:  This object is a defined Octree object
  // Post: RV = root
  OctNode * getRoot();

  // Pre:  This object is a defined Octree object
  // Post: The space has been divided
  void createTree();

  // Pre:  This object is a defined Octree object
  // Post: The nodes have been sent to the OS in postorder traversal
  void postOrderOutput();
  
};

#endif
