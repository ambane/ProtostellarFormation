#ifndef NTREENODE_H
#define NTREENODE_H

#include "ParticleArray.h"
#include "Vector.h"
#include "Particle.h"
#include <vector>

class NTreeNode
{
public:
    NTreeNode();
    NTreeNode(int pNumDivisions, int pSize, NTreeNode * pParent,
              Vector<long long, long long, long long> * pPoint);
    NTreeNode(int pNumDivisions, int pSize,
              Vector<long long, long long, long long> * pPoint,
              ParticleArray * pElements);
    void divideSpace();
    void assignParticles();
    ParticleArray * getElements();
    void addElement(Particle * pParticle);
    std::vector<NTreeNode*> getChildren();
    NTreeNode * getChild(int xLoc, int yLoc);
    NTreeNode * getChild(int index);
    int getNumDivisions();
    void setLargeRadius();
    int getLargeRadius();
    int getSize();
    Vector<long long, long long, long long> * getPoint();
    NTreeNode * getParent();
    int getMass();

private:
    NTreeNode * parent;
    std::vector<NTreeNode*> children;
    int numDivisions;
    int size;
    ParticleArray * elements;
    long long mass;
    Vector<long long, long long, long long> * point;
    int largeRadius;


};

#endif // NTREENODE_H
