#include "Particle.h"
#include "Vector.h"
#include <iostream>
#include <fstream>
using namespace std;

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// CONSTRUCTORS
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

// Pre:
// Post: ID = 0
//       position = <0.0, 0.0, 0.0>
//       velocity = <0, 0, 0>
//       mass = 0
//       radius = 0
Particle::Particle () {
  ID = 0;
  position = new Vector<long long, long long, long long>();
  velocity = new Vector<long long, long long, long long>();
  mass = 0;
  radius = 0;
  isNull = false;
}

// Pre:  pID is an integer value
//       pVector is a defined Vector object passed by reference as a const
//        of type <long long, long long, long long>
//       pVelocity is a defined Vector object passed by reference as a const
//        of type <long long, long long, long long>
//       pMass is a float object
//       pRadius is a float object
// Post: ID = pID
//       position = pVector
//       velocity = pVelocity
//       mass = pMass
//       radius = pRadius
Particle::Particle (int pID, const Vector<long long, long long, long long> & pPosition,
            const Vector<long long, long long, long long> & pVelocity,
		    float pMass, float pRadius) {
  ID = pID;
  position = new Vector<long long, long long, long long>();
  *position = pPosition;
  velocity = new Vector<long long, long long, long long>();
  *velocity = pVelocity;
  mass = pMass;
  radius = pRadius;
  isNull = false;
}

// Pre:  pID is an integer value
//       x_coord, y_coord, and z_coord are long long objects
//       x_vel, y_vel, z_vel are long long objects
//       pMass is a float object
//       pRadius is a float object
// Post: ID = pID
//       position = <x_coord, y_coord, z_coord>
//       velocity = <x_vel, y_vel, z_vel>
//       mass = pMass
//       radius = pRadius
Particle::Particle (int pID, long long x_coord, long long y_coord, long long z_coord,
            long long x_vel, long long y_vel, long long z_vel,
		    float pMass, float pRadius) {
  ID = pID;
  position = new Vector<long long, long long, long long> (x_coord, y_coord, z_coord);
  velocity = new Vector<long long, long long, long long> (x_vel, y_vel, z_vel);
  mass = pMass;
  radius = pRadius;
  isNull = false;
}

// Pre:  This object is a defined Particle object
//       pParticle is a defined Particle object
// Post: This object is a deep copy of pParticle
Particle::Particle (const Particle & pParticle) {
  ID = pParticle.ID;
  position = new Vector<long long, long long, long long>();
  *position = *(pParticle.position);
  velocity = new Vector<long long, long long, long long>();
  *velocity = *(pParticle.velocity);
  mass = pParticle.mass;
  radius = pParticle.radius;
  isNull = false;
}

// Pre:  This object is a defined Particle object
// Post: All allocated heap space has been deallocated
Particle::~Particle () {
  delete position;
  delete velocity;
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// GETTERS
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

// Pre:  This object is a defined Particle object
// Post: RV = ID
int Particle::getID() const {
  return(ID);
}

// Pre:  This object is a defined Particle object
// Post: RV = position
Vector<long long, long long, long long> * Particle::getPosition() const {
  return(position);
}


// Pre:  This object is a defined Particle object
// Post: RV = velocity
Vector<long long, long long, long long> * Particle::getVelocity() const {
  return(velocity);
}

// Pre:  This object is a defined Particle object
// Post: RV = mass
double Particle::getMass() const {
  return(mass);
}

// Pre:  This object is a defined Particle object
// Post: RV = radius
double Particle::getRadius() const {
  return(radius);
}

// Pre:  This object is a defined Particle object
// Post: RV = isNull
bool Particle::getIsNull() const {
  return(isNull);
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// SETTERS
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

// Pre:  This object is a defined Particle object
//       pID is an int
// Post: ID = pID
void Particle::setID(int pID) {
  ID = pID;
}

// Pre:  This object is a defined Particle object
//       pVector is a defined Vector object passed by reference as a const
//        of type <long long, long long, long long>
// Post: position = pVector
void Particle::setPositionWithVector(const Vector<long long, long long, long long> &
				      pVector) {
  *position = pVector;
}

// Pre:  This object is a defined Particle object
//       x_coord, y_coord, and z_coord are long long objects
// Post: position = <x_coord, y_coord, z_coord>
void Particle::setPositionWithCoords(long long x_coord, long long y_coord,
                     long long z_coord) {
  position->setCoordinates(x_coord, y_coord, z_coord);
}

// Pre:  This object is a defined Particle object
//       pTime is an int
// Post: position += velocity * pTime
void Particle::setPositionWithTime(int pTime) {
  *position = *position + (*velocity * pTime);
}

// Pre:  This object is a defined Particle object
//       pVector is a defined Vector object passed by reference as a const
//        of type <long long, long long, long long>
// Post: velocity = pVector
void Particle::setVelocityWithVector(const Vector<long long, long long, long long> &
				     pVector) {
  *velocity = pVector;
}

// Pre:  This object is a defined Particle object
//       x_vel, y_vel, and z_vel are long long objects
// Post: velocity = <x_vel, y_vel, z_vel>
void Particle::setVelocityWithValues(long long x_vel, long long y_vel, long long z_vel) {
  velocity->setCoordinates(x_vel, y_vel, z_vel);
}

// Pre:  This object is a defined Particle object
//       pMass is a float object
// Post: mass = pMass
void Particle::setMass(float pMass) {
  mass = pMass;
}

// Pre:  This object is a defined Particle object
//       pRadius is a float object
// Post: radius = pRadius
void Particle::setRadius(float pRadius) {
  radius = pRadius;
}

// Pre:  This object is a defined Particle object
//       pBool is a bool value
// Post: isNull = pBool
void Particle::setIsNull(bool pBool) {
  isNull = pBool;
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// HELPERS
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////


// Pre:  This object is a defined Particle object
//       pParticle is a Particle object passed as a const by reference
// Post: RV = the long long distance between the two particles
long long Particle::calculateDistance(const Particle & pParticle) const {
  long long distance = position->findDistance(*(pParticle.position));
  return(distance);  
}

// Pre:  This object is a defined Particle object
//       pPos is a Vector<long long, long long, long long> object passed as a const by ref
// Post: RV = the integer representing the time this object will take to
//             reach pPos at velocity
float Particle::calculateTime(const Vector<long long, long long, long long> & pPos) const {
  long long distance = position->findDistance(pPos);
  float velocityMag = velocity->getMagnitude();
  float time = distance / velocityMag;
  return(time);
}

// Pre:  This object is a defined Particle object
//       acceleration is a defined Vector object of type <long long, long long, long long>
// Post: velocity has been modified to account for the acceleration
void Particle::accelerateParticle(const Vector<long long, long long, long long> &
				  acceleration) {
  *velocity = *velocity + acceleration;
}

// Pre:  This object is a defined Particle object
// Post: position = position + velocity
void Particle::updatePosition () {
  *position = *position + *velocity;
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// OPERATORS
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

// Pre:  This object is a defined Particle object
//       pParticle is a defined Particle object
// Post: RV = this object where this object now has
//            mass = mass + pParticle.mass, position = the midpoint between
//            this object and pParticle,
//            velocity = velocity + pParticle.velocity and the
//            radius = radius + pParticle.radius
Particle Particle::operator + (const Particle & pParticle) {
  Particle newParticle;
  newParticle.mass = mass + pParticle.mass;
  long long new_x = (position->getX() + pParticle.position->getX()) / 2;
  long long new_y = (position->getY() + pParticle.position->getY()) / 2;
  long long new_z = (position->getZ() + pParticle.position->getZ()) / 2;
  newParticle.position->setCoordinates(new_x, new_y, new_z);
  *newParticle.velocity = ((*velocity + *(pParticle.velocity)) /
			   newParticle.mass);
  newParticle.radius = radius + pParticle.radius;
  return(newParticle);
}

// Pre:  This object is a defined Particle object
//       pParticle is a defined Particle object
// Post: RV = this object where mass = pParticle.mass,
//            position = pParticle.position, velocity = pParticle.velocity,
//            and radius = pParticle.radius
Particle Particle::operator = (const Particle & pParticle) {
  mass = pParticle.mass;
  position = new Vector<long long, long long, long long>();
  velocity = new Vector<long long, long long, long long>();
  *position = *pParticle.position;
  *velocity = *(pParticle.velocity);
  radius = pParticle.radius;
  return(*this);
}

// Pre:  This object is a defined Particle object
//       pParticle is a defined Particle object
// Post: RV = true iff mass == pParticle.mass and radius = pParticle.radius
//                 and velocity == pParticle.velocity and ID = pParticle.ID
bool Particle::operator == (const Particle & pParticle) const {
  return((mass == pParticle.mass) && (radius == pParticle.radius) &&
	 (velocity == pParticle.velocity) && (ID == pParticle.ID));
}

// Pre:  This object is a defined Particle object
//       pID is an int representing the ID of a Particle object
// Post: RV = true iff ID == pID
bool Particle::operator == (int pID) const {
  return(ID == pID);
}

// Pre:  This object is a defined Particle object
//       pID is an int object
// Post: RV = true iff ID > pID
bool Particle::operator > (int pID) const {
  return(ID > pID);
}

// Pre:  stream is an ostream object
//       pParticle is a defined Particle object
// Post: RV = stream where stream contains the data from pParticle
ostream & operator << (ostream & stream, const Particle & pParticle) {
  stream << pParticle.ID << ' ' << *(pParticle.position) << ' '
         << *(pParticle.velocity) << ' ' << pParticle.mass << ' '
         << pParticle.radius << endl;
  return(stream);
} 

// Pre:  file is an ifstream object
//       pParticle is a defined Particle object
// Post: RV = file
//       pParticle contains the data from file
ifstream & operator >> (ifstream & file, Particle & pParticle) {
  file >> *pParticle.position;
  file >> *pParticle.velocity;
  file >> pParticle.mass;
  file >> pParticle.radius;
  return(file);
}
