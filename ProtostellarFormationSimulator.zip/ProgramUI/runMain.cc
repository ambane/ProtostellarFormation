#include "IOFile.h"
#include "Gravity.h"
#include "Collision.h"
#include "Octree.h"
#include "OctNode.h"
#include "ParticleArray.h"
#include "IOConstants.h"
#include "ProcessTimestep.h"
#include "Vector.h"
#include "Particle.h"
#include <fstream>
#include <sys/times.h>
#include <unistd.h>
using namespace std;

int main (int argc, char ** argv) {
  ParticleArray * particleArray = new ParticleArray();
  //writeFile(argv[1]);
  // A file containing randomly generated particles has been created. The
  // particles have a position that is bounded by the length found in
  // IOConstants, and the velocity is bounded by the max velocity in
  // IOConstants. All masses and radii are the same as determined in
  // IOConstants.
  readFile(argv[1], particleArray);
  // particleArray contains the particle object from the file created earlier.
  ofstream collisionsFile(argv[2]);
  ofstream timeFile("TimeFileCollisions6.csv");
  ofstream postParticle("PostParticleFile6-1.txt");
  int minLength = 500;
  int minParticles = 100;
  Octree particleTree(LENGTH, NUM_PARTICLES, particleArray,
		      minLength, minParticles);
  // particleTree is an octree where the root contains the total space and
  // each child OctNode contains an octant of the total space represented by
  // its parent. The minimum length of the octant and the minimum number of
  // particles in each octant are minLength and minParticles, respectively.
  long ticksPerSecond = sysconf(_SC_CLK_TCK);
  struct tms timeStructure;
  for (int index = 0; index < 15; index ++) {
    int numCollisions = 0;
    time_t startTimeStepTime = times(&timeStructure);
    for (int subIndex = 0; subIndex < 50; subIndex ++) {
      processTimestep(particleTree, numCollisions);
      cout << "NUM COLLISIONS " << index << '-' << subIndex << ": "
	   << numCollisions << endl;
    }
    time_t endTimeStepTime = times(&timeStructure);
    long TimeStepTime = ((endTimeStepTime - startTimeStepTime) /
			 ticksPerSecond);
    timeFile << TimeStepTime << ", "; 
    collisionsFile << numCollisions << ", ";
  }
  Particle * currParticle;
  Vector<float, float, float> * currPosition;
  Vector<float, float, float> * currVelocity;
  for (int particles = 0; particles < particleArray->getNumElements();
       particles++) {
    currParticle = particleArray->getIthObject(particles);
    currPosition = currParticle->getPosition();
    currVelocity = currParticle->getVelocity();
    postParticle << currPosition->getX() << ' ' << currPosition->getY() << ' '
		 << currPosition->getZ() << ' ' << currVelocity->getX() << ' '
		 << currVelocity->getY() << ' ' << currVelocity->getZ() << ' '
		 << currParticle->getMass() << ' ' << currParticle->getRadius()
		 << endl;
  }
  postParticle.close();
  timeFile.close();
  collisionsFile.close();
  return(0);
}
