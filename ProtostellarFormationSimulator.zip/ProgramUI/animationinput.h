#ifndef ANIMATIONINPUT_H
#define ANIMATIONINPUT_H

#include <QWidget>
#include <string>
#include "animationwindow.h"

namespace Ui {
class AnimationInput;
}

class AnimationInput : public QWidget
{
    Q_OBJECT

public:
    explicit AnimationInput(QWidget *parent = 0);
    ~AnimationInput();
    int getNumFiles();
    std::string getPath();
    bool getOK();
    int getClusterSize();

private:
    Ui::AnimationInput *ui;
    AnimationWindow * animation;
    int numFiles;
    int clusterSize;
    std::string path;
    bool ok;

private slots:
    void handleOK();
};

#endif // ANIMATIONINPUT_H
