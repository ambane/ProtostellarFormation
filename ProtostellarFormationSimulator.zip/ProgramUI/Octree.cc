#include "Octree.h"
#include "OctNode.h"
#include "Particle.h"
#include "ParticleArray.h"
#include <iostream>
using namespace std;

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// CONSTRUCTORS
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

// Pre:
// Post: This object is an Octree object
//        root has been allocated space on the heap
//        numElements = 0
Octree::Octree () {
  root = new OctNode();
  numElements = 0;
  minLength = 1;
  minCount = 1;
}

// Pre:  length is a double representing the space contained in this object
//       pNumElements is the number of elements contained in this object
//       pElements is the objectArray object containing pointers to the
//        objects in this space
//       pMinLength is the minimum length of an octant n such that if the
//        length of an octant <= n, the octant will not be divided
//       pMinCount is the minimum number of particles to be in an octant, n
//        such that if the number of elements in the octant <= n, the
//        octant will not be divided
// Post: root is an OctNode pointer containing pLength, pNumElements,
//        and pElements
//       numElements = pNumElements
//       minLength = pMinLength
//       minCount = pMinCount
Octree::Octree (long long pLength, int pNumElements,
        ParticleArray * pElements,
        float pMinLength, int pMinCount) {
  root = new OctNode(pLength, pNumElements, pElements);
  numElements = pNumElements;
  minLength = pMinLength;
  minCount = pMinCount;
  createTreeHelper(root, false);
}

// Pre:  This object is a defined Octree object
// Post: All dynamic memory has been deallocated
//       root is NULL
//       numElements is 0
Octree::~Octree () {
  delete root;
  root = NULL;
  numElements = 0;
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// GETTERS
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

// Pre:  This object is a defined Octree object
// Post: RV = root
OctNode * Octree::getRoot() {
  return(root);
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// HELPERS
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

// Pre:  This object is a defined Octree object
//       root is a pointer to a defined OctNode object
//       baseCase is false
// Post: This object has been created and the space contained in the root
//        has been recursively divided until the base length or minimum
//        contained objects was found
void Octree::createTreeHelper(OctNode * pRoot, bool baseCase) {
  if ((pRoot->getLength() <= minLength) ||
      (pRoot->getNumElements() <= minCount)) {
    baseCase = true;
  }
  else if (!baseCase) {
    pRoot->divideSpace();
    pRoot->assignParticles();
    for (int count = 0; count < OCT; count ++) {
      createTreeHelper(pRoot->getIthChild(count), false);
    }
  }
}

// Pre:  This object is a defined Octree object
// Post: The space has been divided
void Octree::createTree() {
  if (root->getIthChild(0) != NULL) {
    for (int index = 0; index < OCT; index ++) {
      delete(root->getIthChild(index));
    }
  }
  if ((minLength < root->getLength())
      && (root->getNumElements() > minCount)) {
    createTreeHelper(root, false);
  }
}

// Pre:  This object is a defined Octree object
// Post: The nodes have been sent to the OS in postorder traversal
void Octree::postOrderOutput() {
  postOrderOutputHelper(root);
}

// Pre:  This object is a defined Octree object
// Post: The nodes have been sent to the OS in Postorder Traversal
void Octree::postOrderOutputHelper(OctNode * pRoot) {
  if (pRoot->getNumChildren() != 0) {
    OctNode * child;
    for (int index = 0; index < OCT; index ++) {
      child = pRoot->getIthChild(index);
      postOrderOutputHelper(child);
    }
  }
  cout << *pRoot;
}
