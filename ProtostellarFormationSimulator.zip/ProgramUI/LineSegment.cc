#include "LineSegment.h"
#include "Vector.h"
#include "Particle.h"
#include <iostream>
using namespace std;

// Pre: 
// Post: This object has been constructed. start and end have been
//        constructed and are both <0, 0, 0> and xDenom, yDenom, and zDenom
//        are all 1
LineSegment::LineSegment () {
}

// Pre:  pStart and pEnd are Vector<long long, long long, long long> objects
// Post: start = pStart, end = pEnd, and xDenom, yDenom, and zDenom
//        have been set
LineSegment::LineSegment (int pID, const Vector<long long, long long, long long> & pStart,
              const Vector<long long, long long, long long> & pEnd) {
  ID = pID;
  start.setCoordinates(pStart.getX(), pStart.getY(), pStart.getZ());
  end.setCoordinates(pEnd.getX(), pEnd.getY(), pEnd.getZ());
}

// Pre:  pParticle is a Particle passed as a const by reference
// Post: start = pParticle.getPosition(), end = start + pParticle.getVelocity(),
//        and ID = pParticle.ID
LineSegment::LineSegment (const Particle & pParticle) {
  ID = pParticle.getID();
  start = *pParticle.getPosition();
  end = *pParticle.getPosition() + *pParticle.getVelocity();
}

// Pre:  pID is an integer
//       pStart and pEnd are Vector<long long, long long, long long> objects
// Post: ID = pID, start = pStart, end = pEnd, and xDenom, yDenom, and zDenom
//        have been set
void LineSegment::setData(int pID, const Vector<long long, long long, long long> & pStart,
              const Vector<long long, long long, long long> & pEnd) {
  ID = pID;
  start.setCoordinates(pStart.getX(), pStart.getY(), pStart.getZ());
  end.setCoordinates(pEnd.getX(), pEnd.getY(), pEnd.getZ());
}

// Pre:  This object is a well defined LineSegment object and is const
//       pSegment is a well defined LineSegment object that is passed by
//        reference as a const
// Post: RV = the Vector<long long, long long, long long> object that represents the point
//            of intersection between this object and pSegment
void LineSegment::findIntersection(const LineSegment & pSegment,
                   Vector<long long, long long, long long> & intersection,
				   bool & intersect) const {
  //(Weisstein, Eric W. "Skew Lines." From MathWorld--A Wolfram Web Resource.
  // http://mathworld.wolfram.com/SkewLines.html)
  Vector<long long, long long, long long> start1 = start;
  Vector<long long, long long, long long> end1 = end;
  Vector<long long, long long, long long> start2 = pSegment.start;
  Vector<long long, long long, long long> end2 = pSegment.end;
  Vector<long long, long long, long long> aVector = end1 - start1;
  Vector<long long, long long, long long> bVector = end2 - start2;
  Vector<long long, long long, long long> cVector = start2 - start1;
  float skew = (cVector).getDotProduct(aVector.getCrossProduct(bVector));
  bool skewLines = (skew == 0);
  if (!skewLines) {
    Vector<long long, long long, long long> aCrossB = aVector.getCrossProduct(bVector);
    float sVal = (((cVector.getCrossProduct(bVector)).getDotProduct(aCrossB))
		  / pow(aCrossB.getMagnitude(), 2));
    // sVal = ((cVector x bVector) * (aVector x bVector)) /
    //           (|aVector x bVector|) ^ 2
    //         (http://mathworld.wolfram.com/Line-LineIntersection.html)
    intersection = start1 + (aVector * sVal);
    if ((isBetween(intersection)) && (pSegment.isBetween(intersection))) {
      intersect = true;
    }
  }
}

// Pre:  This object is a well defined LineSegment object
//       pVector is a defined Vector object passed by reference as a const
// Post: RV = true iff pVector is between start and end
bool LineSegment::isBetween(const Vector<long long, long long, long long> & pVector) const {
  long long testX = pVector.getX();
  long long testY = pVector.getY();
  long long testZ = pVector.getZ();
  long long startX = start.getX();
  long long endX = end.getX();
  long long startY = start.getY();
  long long endY = end.getY();
  long long startZ = start.getZ();
  long long endZ = end.getZ();
  bool between = ((((testX > startX) && (testX <= endX)) ||
		   ((testX < startX) && (testX >= endX))) &&
		  (((testY > startY) && (testY <= endY)) ||
		   ((testY < startY) && (testY >= endY))) &&
		  (((testZ > startZ) && (testZ <= endZ)) ||
		   ((testZ < startZ) && (testZ >= endZ))));
  return(between);
}

// Pre:  This object is a well defined LineSegment object
//       pSegment is a defined LineSegment object
// Post: RV = this where all member data of this segment = pSegment
LineSegment LineSegment::operator = (const LineSegment & pSegment) {
  ID = pSegment.ID;
  start = pSegment.start;
  end = pSegment.end;
  return(*this);
}
  

// Pre:  This object is a well defined LineSegment object
//       pSegment is a defined LineSegment object
// Post: RV = true iff start.x < pSegment.start.x
bool LineSegment::operator < (const LineSegment & pSegment) const {
  bool isLess = false;
  if (((start.getY() < pSegment.start.getY()) &&
       (end.getY() < pSegment.end.getY())) ||
      ((start.getZ() < pSegment.start.getZ()) &&
       (end.getZ() < pSegment.end.getZ()))) {
    isLess = true;
  }
  return(isLess);
}

// Pre:  This object is a well defined LineSegment object
//       pSegment is a defined LineSegment object
// Post: RV = true iff start.x > pSegment.start.x
bool LineSegment::operator > (const LineSegment & pSegment) const {
  bool isGreater = false;
  if (((start.getY() > pSegment.start.getY()) &&
       (end.getY() > pSegment.end.getY())) ||
      ((start.getZ() > pSegment.start.getZ()) &&
       (end.getZ() > pSegment.end.getZ()))) {
    isGreater = true;
  }
  return(isGreater);
}

// Pre:  This object is a well defined LineSegment object
//       pSegment is a defined LineSegment object
// Post: RV = true iff start == pSegment.start and end = pSegment.end
bool LineSegment::operator == (const LineSegment & pSegment) const {
  return((start == pSegment.start) && (end == pSegment.end));
}

// Pre:  This object is a well defined LineSegment object
//       pSegment is a defined LineSegment object
// Post: RV = true iff !(this == pSegment)
bool LineSegment::operator != (const LineSegment & pSegment) const {
  return(!((start == pSegment.start) && (end == pSegment.end)));
}

// Pre:  This object is a well defined LineSegment object
//       pSegment is a defined LineSegment object
// Post: RV = true iff this < pSegment or this == pSegment
bool LineSegment::operator <= (const LineSegment & pSegment) const {
  return((*this == pSegment) || (*this < pSegment));
}

// Pre:  This object is a well defined LineSegment object
//       pSegment is a defined LineSegment object
// Post: RV = true iff this > pSegment or this == pSegment
bool LineSegment::operator >= (const LineSegment & pSegment) const {
  return((*this == pSegment) || (*this > pSegment));
}

// Pre:  stream is a defined ostream object
//       pSegment is a defined LineSegment object passed by reference as a const
// Post: RV = stream which contains the data from pSegment
ostream & operator << (ostream & stream, const LineSegment & pSegment) {
  stream << "ID: " << pSegment.ID << endl;
  stream << "Start: " << pSegment.start;
  stream << "End: " << pSegment.end;
}
