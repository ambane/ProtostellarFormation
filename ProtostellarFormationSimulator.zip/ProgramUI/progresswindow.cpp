#include "progresswindow.h"
#include "ui_progresswindow.h"

ProgressWindow::ProgressWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ProgressWindow)
{
    ui->setupUi(this);
}

ProgressWindow::~ProgressWindow()
{
    delete ui;
}

void ProgressWindow::processedCount(int numProcessed) {
    ui->ProcessedNumber->display(numProcessed);
}

void ProgressWindow::leftCount(int numLeft) {
    ui->LeftNumber->display(numLeft);
}
