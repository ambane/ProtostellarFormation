#ifndef ANIMATIONPARTICLE_H
#define ANIMATIONPARTICLE_H

#include <QPoint>

class AnimationParticle
{
public:
    AnimationParticle();
    AnimationParticle(int pRadius, const QPoint & pPoint);
    AnimationParticle(int pRadius, int xLoc, int yLoc);
    int getRadius ();
    QPoint getPoint();
    void setRadius (int pRadius);
    void setPoint (const QPoint & pPoint);

private:
    int radius;
    QPoint point;
};

#endif // ANIMATIONPARTICLE_H
