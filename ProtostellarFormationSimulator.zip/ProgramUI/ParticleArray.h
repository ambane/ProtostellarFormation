#ifndef included_ParticleArray
#define included_ParticleArray

#include "ObjectArray.h"
#include "Particle.h"
class ParticleArray : public ObjectArray<Particle*> {

 private:

 public:

  // Pre:  This object is a defined ParticleArray object
  // Post: All memory has been deallocated
  ~ParticleArray();

  // Pre:  This object is a defined ParticleArray object
  // Post: All pointers in this object are NULL
  void AllNull();
  
  // Pre:  This object is a defined objectArray object
  //       pID is an integer representing the ID of an object in the array
  //       the array must be sorted
  // Post: RV = the object in the array that has the ID == pID
  Particle * searchWithID(int pID);

  // Pre:  This object is a defined objectArray object
  // Post: All Particles n such that n.isNull = true have been deleted and the
  //        array has been adjusted.
  void deleteNullParticles();

  
  // Pre:  This object is a defined objectArray object
  // Post: All Particles n have had their positions updated according to
  //        their previous positions and their velocities
  void updatePositions();

  // Pre:  This object is a defined objectArray object
  // Post: All Particles n such that n.isNull = true have been moved to the
  //        end of the array
  void moveNullParticles();
  
  // Pre:  This object is a defined objectArray object
  //        pIndex is an int < numElements passed by reference
  // Post: pIndex = the index of the first non-null Particle from pIndex
  void findNonNull(int & pIndex);

};

#endif
