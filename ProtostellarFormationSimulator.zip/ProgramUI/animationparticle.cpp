#include "animationparticle.h"
#include <QPoint>

AnimationParticle::AnimationParticle()
{
}

AnimationParticle::AnimationParticle(int pRadius, const QPoint & pPoint) {
    radius = pRadius;
    point = pPoint;
}

AnimationParticle::AnimationParticle(int pRadius, int xLoc, int yLoc) {
    radius = pRadius;
    QPoint pPoint(xLoc, yLoc);
    point = pPoint;
}

int AnimationParticle::getRadius () {
    return(radius);
}

QPoint AnimationParticle::getPoint () {
    return(point);
}

void AnimationParticle::setRadius (int pRadius) {
    radius = pRadius;
}

void AnimationParticle::setPoint (const QPoint & pPoint) {
    point = pPoint;
}
