#include "ProcessTimestep.h"
#include "Gravity.h"
#include "Collision.h"
#include "Octree.h"
#include "OctNode.h"
#include "Exception.h"
#include <iostream>
#include <fstream>
using namespace std;

// Pre:  spaceTree is an Octree passed by reference
//       numCollisions is an int passed by reference
// Post: All collisions during the timestep for all particles have been found
//        and processed
void processTimestep(Octree & spaceTree, int & numCollisions, double timestepDuration, int mergeFactor, ofstream & collisionLocation, ofstream & escapedParticles) {
  OctNode * root = spaceTree.getRoot();
  if (root->getNumChildren() != 0) {
    findLeaves(root, numCollisions, timestepDuration, mergeFactor, collisionLocation);
  }
  else {
    cellGravity(root->getElements(), timestepDuration);
    runCollisions(root->getElements(), numCollisions, mergeFactor, collisionLocation);
  }
  int numEscaped = 0;
  root->getElements()->updatePositions();
  findEscapedParticles(root->getElements(), root->getLength(), numEscaped);
  escapedParticles << numEscaped << ' ';
  root->getElements()->deleteNullParticles();
  root->setNumElements(root->getElements()->getNumElements());
  spaceTree.setNumElements(root->getNumElements());
  spaceTree.createTree();
}

// Pre:  pNode is a pointer to an OctNode<Particle*> object
// Post: All gravitational forces have been calculated for any leaves below
//        pNode or, if pNode is a leaf, the gravitational forces have been
//        calculated for it and its siblings
void findLeaves(OctNode * pNode, int & numCollisions, double timestepDuration, int mergeFactor, ofstream & collisionLocation) {
  OctNode * currNode;
  int numParticles;
  ParticleArray * currParticles;
  for (int index = 0; index < OCT; index ++) {
    currNode = pNode->getIthChild(index);
    numParticles = currNode->getNumElements();
    currParticles = currNode->getElements();
    if (currNode->getIthChild(0) == NULL) {
      // ASSERT: currNode is a leaf.
      if (numParticles != 0) {
	// ASSERT: numParticles >= 1.
	if (numParticles > 1) {
	  // ASSERT: numParticles > 1.
	  try {
        cellGravity(currParticles, timestepDuration);
        siblingGravity(*currNode, index, *pNode, timestepDuration);
        runCollisions(currParticles, numCollisions, mergeFactor, collisionLocation);
	  }
	  catch (Exception e) {
	    e.handle();
	  }
	}
	else {
      siblingGravity(*currNode, index, *pNode, timestepDuration);
	}
      }
    }
    else {
      // ASSERT: currNode is not a leaf.
      findLeaves(currNode, numCollisions, timestepDuration, mergeFactor,collisionLocation);
    }
  }
}

// Pre:  elements is a pointer to a defined ParticleArray object
//       size is an long long representing the total size of the space
// Post: all Particle* objects that are outside of the bounds have been made NULL
void findEscapedParticles(ParticleArray * elements, long long size, int & numEscaped) {
    Vector<long long, long long, long long> * currPos;
    for (int index = 0; index < elements->getNumElements(); index++) {
        currPos = elements->getIthObject(index)->getPosition();
        if (!((currPos->getX() > 0) && (currPos->getX() < size) &&
             (currPos->getY() > 0) && (currPos->getY() < size) &&
             (currPos->getZ() > 0) && (currPos->getZ() < size))) {
            elements->getIthObject(index)->setIsNull(true);
            numEscaped ++;
        }
    }
}


