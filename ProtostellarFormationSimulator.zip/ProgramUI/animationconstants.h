#ifndef ANIMATIONCONSTANTS_H
#define ANIMATIONCONSTANTS_H

#include <unistd.h>

#define Z_SHIFT .00333
#define WINDOW_SIZE 700
#define PIX_COUNT 5
#define ALPHA 255
const int MILLISECONDS_IN_MICRO = 1000;
#define sleep(time) usleep(time * MILLISECONDS_IN_MICRO)

#endif // ANIMATIONCONSTANTS_H

