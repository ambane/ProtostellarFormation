#ifndef NTREE_H
#define NTREE_H

#include "ParticleArray.h"
#include "ntreenode.h"

class NTree
{
public:
    NTree();
    NTree(int pDivisions, int pSize, ParticleArray * pElements);
    NTreeNode * getRoot();

private:
    NTreeNode * root;
    int numDivisions;
    int size;
    ParticleArray * elements;
};

#endif // NTREE_H
