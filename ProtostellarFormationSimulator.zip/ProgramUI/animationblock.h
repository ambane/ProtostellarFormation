#ifndef ANIMATIONBLOCK_H
#define ANIMATIONBLOCK_H

#include "ObjectArray.h"
#include "Pair.h"

class AnimationBlock
{
public:
    AnimationBlock();
    void addMass(int mass) {massSum += mass;};
    void addParticle(Pair<Pair<int, int>, int> pParticle) {particles.addObject(pParticle);};
    friend ostream & operator << (ostream & stream, const AnimationBlock & pBlock);

private:
    ObjectArray<Pair<Pair<int, int>, int> > particles;
    int massSum;
};

#endif // ANIMATIONBLOCK_H
