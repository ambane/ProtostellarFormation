#ifndef included_BinaryTreeNode
#define included_BinaryTreeNode

#include <iostream>

using namespace std;

template <class T>

class BinaryTreeNode {

  // CI: This object represents a BinaryTreeNode object which contains some integer
  //      as data and two pointers, leftChild and rightChild, which are
  //      themselves BinaryTreeNode objects. The data contained by leftChild must be
  //      less than or equal to the data of this object, and the data contained
  //      by rightChild must be greater than the data of this object. If both
  //      leftChild and rightChild are NULL, this object is a leaf.

 private:

  BinaryTreeNode <T> * parent; // a pointer to the BinaryTreeNode object that is
                         // this object's parent
  BinaryTreeNode <T> * leftChild; // a pointer to a BinaryTreeNode object with data <= data
  BinaryTreeNode <T> * rightChild; // a pointer to a BinaryTreeNode object with data > data
  T data;

 public:

  // Pre:
  // Post: leftChild, rightChild, and parent are NULL
  BinaryTreeNode () {
    parent = NULL;
    leftChild = NULL;
    rightChild = NULL;
  }
  
  // Pre:  pData is an integer
  // Post: leftChild and rightChild are set to NULL
  BinaryTreeNode (const T & pData) {
    parent = NULL;
    leftChild = NULL;
    rightChild = NULL;
    data = pData;
  }

  // Pre:  This object is a well defined BinaryTreeNode object
  // Post: All dynamically allocated memory has been deallocated
  //       leftChild and rightChild are NULL
  ~BinaryTreeNode () {
    if (leftChild != NULL) {
      delete leftChild;
      leftChild = NULL;
    }
    if (rightChild != NULL) {
      delete rightChild;
      rightChild = NULL;
    }
  }

////////////////////////////////////////////////////////////////////////////////
// GETTERS
////////////////////////////////////////////////////////////////////////////////
  
  // Pre:  This object is a well defined BinaryTreeNode object
  // Post: RV = the pointer to leftChild
  BinaryTreeNode <T> * getLeftChild () const {
    return(leftChild);
  }

  // Pre:  This object is a well defined BinaryTreeNode object
  // Post: RV = the pointer to parent
  BinaryTreeNode <T> * getParent () const {
    return(parent);
  }

  // Pre:  This object is a well defined BinaryTreeNode object
  // Post: RV = the pointer to rightChild
  BinaryTreeNode <T> * getRightChild () const {
    return(rightChild);
  }

  // Pre:  This object is a well defined BinaryTreeNode object
  // Post: RV = the data contained by this object
  T getData () const {
    return(data);
  }

  // Pre:  This object is a well defined BinaryTreeNode object
  // Post: RV = true iff this object is a leaf
  bool isLeaf() const {
    return((leftChild == NULL) & (rightChild == NULL));
  }

////////////////////////////////////////////////////////////////////////////////
// SETTERS
////////////////////////////////////////////////////////////////////////////////

  // Pre:  This object is a well defined BinaryTreeNode object
  //       pData is an object of type T passed by reference as a const
  // Post: data = pData
  void setData (const T & pData) {
    data = pData;
  }
  
  // Pre:  This object is a well defined BinaryTreeNode object
  //       pNode is a pointer to a defined BinaryTreeNode object
  // Post: parent is set equal to pNode
  void setParent (BinaryTreeNode <T> * pNode) {
    parent = pNode;
    if (pNode != NULL) {
      if (data < pNode->data) {
	pNode->leftChild = this;
      }
      else {
	pNode->rightChild = this;
      }
    }
  }

  // Pre:  This object is a well defined BinaryTreeNode object
  //       pNode is a pointer to a defined BinaryTreeNode object
  // Post: sets leftChild equal to pNode
  void setLeftChild (BinaryTreeNode <T> * pNode) {
    leftChild = pNode;
    if (pNode != NULL) {
      leftChild->parent = this;
    }
  }

  // Pre:  This object is a well defined BinaryTreeNode object
  //       pNode is a pointer to a defined BinaryTreeNode object
  // Post: sets rightChild equal to pNode
  void setRightChild (BinaryTreeNode <T> * pNode) {
    rightChild = pNode;
    if (pNode != NULL) {
      rightChild->parent = this;
    }
  }

  // Pre:  This object is a well defined BinaryTreeNode object
  // Post: All pointers are NULL
  void setPointersNull() {
    parent = NULL;
    rightChild = NULL;
    leftChild = NULL;
  }

////////////////////////////////////////////////////////////////////////////////
// OPERATORS
////////////////////////////////////////////////////////////////////////////////

  // Pre:  This object is a well defined BinaryTreeNode object
  //       pNode is a defined BinaryTreeNode object passed by reference as a const
  // Post: RV = a pointer to a BinaryTreeNode object that is a deep copy of pNode
  BinaryTreeNode<T> & operator = (const BinaryTreeNode<T> & pNode) {
    data = pNode.data;
    if (pNode.leftChild != NULL) {
      if (leftChild == NULL) {
	BinaryTreeNode<T> * newLeft = new BinaryTreeNode<T>();
	leftChild = newLeft;
      }
      *leftChild = *pNode.leftChild;
      leftChild->parent = this;
    }
    if (pNode.rightChild != NULL) {
      if (rightChild == NULL) {
	BinaryTreeNode<T> * newRight = new BinaryTreeNode<T>();
	rightChild = newRight;
      }
      *rightChild = *pNode.rightChild;
      rightChild->parent = this;
    }
    return(*this);
  }

  // Pre:  pNode is a well defined BinaryTreeNode object
  //       stream is a defined writeable stream
  // Post: stream contains the data contained in pNode
  //       RV = stream
  friend ostream & operator << (ostream & stream,
				const BinaryTreeNode <T> & pNode) {
    stream << pNode.data << endl;
    return(stream);
  }

};

#endif
