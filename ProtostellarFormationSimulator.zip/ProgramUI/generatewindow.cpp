#include "generatewindow.h"
#include "ui_generatewindow.h"
#include "IOFile.h"

GenerateWindow::GenerateWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::GenerateWindow)
{
    ui->setupUi(this);
    connect(ui->ok, SIGNAL(clicked(bool)), this, SLOT(handleOK()));
    connect(ui->cancel, SIGNAL(clicked(bool)), this, SLOT(close()));
}

GenerateWindow::~GenerateWindow()
{
    delete ui;
}

void GenerateWindow::handleOK() {
    int numParticles = ui->NumberofParticles->value();
    double massParticles = ui->MassParticles->value();
    int radiusParticles = ui->RadiusParticles->value();
    int velocityParticles = ui->Velocity->value();
    int spaceSize = ui->RangeSpace->value();
    QString fileName = ui->NameofFile->text();
    this->hide();
    QByteArray nameFileArray = fileName.toLatin1();
    const char * file = nameFileArray.constData();
    writeFile(file, numParticles, massParticles, radiusParticles, velocityParticles, spaceSize);
}
