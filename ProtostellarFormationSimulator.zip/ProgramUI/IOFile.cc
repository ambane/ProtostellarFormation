#include "Particle.h"
#include "IOFile.h"
#include "IOConstants.h"
#include "ParticleArray.h"
#include <stdlib.h>
#include <time.h>
#include <fstream>
using namespace std;

void writeFile (const char * fileName, int numParticles, double massParticles,
                int radius, int maxVelocity, long long spaceSize) {
  ofstream file(fileName);
  file << numParticles << endl;
  spaceSize *= AU_TO_KM;
  file << spaceSize << endl;
  srand (time(NULL));
  for (int index = 0; index < numParticles; index ++) {
    float xPos = rand() % spaceSize;
    float yPos = rand() % spaceSize;
    float zPos = rand() % spaceSize;
    float xVel = (rand() - rand())% maxVelocity;
    float yVel = (rand() - rand())% maxVelocity;
    float zVel = (rand() - rand())% maxVelocity;
    file << xPos << ' ' << yPos << ' ' << zPos << ' '
	 << xVel << ' ' << yVel << ' ' << zVel << ' '
     << massParticles << ' ' << radius << endl;
  }
  file.close();
}

// Pre:
// Post:
void readFile (const char * fileName, ParticleArray * particleArray,
               int & numParticles, long long &spaceSize) {
  ifstream file(fileName);
  file >> numParticles;
  file >> spaceSize;
  float xPos;
  float yPos;
  float zPos;
  float xVel;
  float yVel;
  float zVel;
  float mass;
  float radius;
  for (int index = 0; index < numParticles; index ++) {
    file >> xPos;
    file >> yPos;
    file >> zPos;
    file >> xVel;
    file >> yVel;
    file >> zVel;
    file >> mass;
    file >> radius;
    Particle * newParticle = new Particle(index, xPos, yPos, zPos, xVel,
					  yVel, zVel, mass, radius);
    particleArray->addObject(newParticle);
  }
  file.close();
}
