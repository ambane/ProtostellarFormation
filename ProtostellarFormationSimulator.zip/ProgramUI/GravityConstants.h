#ifndef included_GravityConstants
#define included_GravityConstants

#include <math.h>

#define GRAV_CONSTANT 1.327 * pow(10, 11)
#define SOLAR_MASS 1.989 * pow(10, 30)
#define KILOMETER 1000
#define TIMESTEP 1

#endif
