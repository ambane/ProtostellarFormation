#ifndef included_Particle
#define included_Particle

#include "Vector.h"
#include <iostream>
#include <fstream>
using namespace std;

class Particle {

  // CI: This object contains a pointer to a Vector object of type
  //      <long long, long long, long long> representing its current position in a three
  //      dimensional space, called position
  //     This object contains a pointer to a Vector object of type
  //      <long long, long long, long long> representing its velocity in a three dimensions
  //     This object contains a floating point value called mass representing
  //      its mass in solar masses (1 solar mass = 1.989 * 10^30 kg)
  //     This object contains a floating point value called radius representing
  //      its radius in kilometers

 private:

  int ID;
  Vector<long long, long long, long long> * position;
  Vector<long long, long long, long long> * velocity;
  double mass;
  double radius;
  bool isNull;

 public:

  // Pre:
  // Post: ID = 0
  //       position = <0.0, 0.0, 0.0>
  //       velocity = <0, 0, 0>
  //       mass = 0
  //       radius = 0
  Particle ();

  // Pre:  pID is an integer value
  //       pVector is a defined Vector object passed by reference as a const
  //        of type <long long, long long, long long>
  //       pVelocity is a defined Vector object passed by reference as a const
  //        of type <long long, long long, long long>
  //       pMass is a float object
  //       pRadius is a float object
  // Post: ID = pID
  //       position = pVector
  //       velocity = pVelocity
  //       mass = pMass
  //       radius = pRadius
  Particle (int pID, const Vector<long long, long long, long long> & pPosition,
        const Vector<long long, long long, long long> & pVelocity,
        float pMass, float pRadius);

  // Pre:  pID is an integer value
  //       x_coord, y_coord, and z_coord are long long objects
  //       x_vel, y_vel, z_vel are long long objects
  //       pMass is a float object
  //       pRadius is a float object
  // Post: ID = pID
  //       position = <x_coord, y_coord, z_coord>
  //       velocity = <x_vel, y_vel, z_vel>
  //       mass = pMass
  //       radius = pRadius
  Particle (int pID, long long x_coord, long long y_coord, long long z_coord,
        long long x_vel, long long y_vel, long long z_vel,
	    float pMass, float pRadius);

  // Pre:  This object is a defined Particle object
  // Post: All allocated heap space has been deallocated
  ~Particle ();

  // Pre:  This object is a defined Particle object
  //       pParticle is a defined Particle object
  // Post: This object is a deep copy of pParticle
  Particle (const Particle & pParticle);

  // Pre:  This object is a defined Particle object
  // Post: RV = ID
  int getID() const;

  // Pre:  This object is a defined Particle object
  // Post: RV = position
  Vector<long long, long long, long long> * getPosition() const;

  // Pre:  This object is a defined Particle object
  // Post: RV = velocity
  Vector<long long, long long, long long> * getVelocity() const;

  // Pre:  This object is a defined Particle object
  // Post: RV = mass
  double getMass() const;

  // Pre:  This object is a defined Particle object
  // Post: RV = radius
  double getRadius() const;

  // Pre:  This object is a defined Particle object
  // Post: RV = isNull
  bool getIsNull() const;

  // Pre:  This object is a defined Particle object
  //       pID is an int
  // Post: ID = pID
  void setID(int pID);

  // Pre:  This object is a defined Particle object
  //       pVector is a defined Vector object passed by reference as a const
  //        of type <long long, long long, long long>
  // Post: position = pVector
  void setPositionWithVector(const Vector<long long, long long, long long> & pVector);

  // Pre:  This object is a defined Particle object
  //       x_coord, y_coord, and z_coord are long long objects
  // Post: position = <x_coord, y_coord, z_coord>
  void setPositionWithCoords(long long x_coord, long long y_coord, long long z_coord);

  // Pre:  This object is a defined Particle object
  //       pTime is an int
  // Post: position += velocity * pTime
  void setPositionWithTime(int pTime);

  // Pre:  This object is a defined Particle object
  //       pVector is a defined Vector object passed by reference as a const
  //        of type <long long, long long, long long>
  // Post: velocity = pVector
  void setVelocityWithVector(const Vector<long long, long long, long long> & pVector);

  // Pre:  This object is a defined Particle object
  //       x_vel, y_vel, and z_vel are long long objects
  // Post: velocity = <x_vel, y_vel, z_vel>
  void setVelocityWithValues(long long x_vel, long long y_vel, long long z_vel);

  // Pre:  This object is a defined Particle object
  //       pMass is a float object
  // Post: mass = pMass
  void setMass(float pMass);

  // Pre:  This object is a defined Particle object
  //       pRadius is a float object
  // Post: radius = pRadius
  void setRadius(float pRadius);

  // Pre:  This object is a defined Particle object
  //       pBool is a bool value
  // Post: isNull = pBool
  void setIsNull(bool pBool);

  // Pre:  This object is a defined Particle object
  //       pParticle is a Particle object passed as a const by reference
  // Post: RV = the long long distance between the two particles
  long long calculateDistance(const Particle & pParticle) const;

  // Pre:  This object is a defined Particle object
  //       pPos is a Vector<long long, long long, long long> object passed as a const by ref
  // Post: RV = the integer representing the time this object will take to
  //             reach pPos at velocity
  float calculateTime(const Vector<long long, long long, long long> & pPos) const;

  // Pre:  This object is a defined Particle object
  //       acceleration is a defined Vector object of type <long long, long long, long long>
  // Post: velocity has been modified to account for the acceleration
  void accelerateParticle(const Vector<long long, long long, long long> & acceleration);

  // Pre:  This object is a defined Particle object
  // Post: position = position + velocity
  void updatePosition ();
  
  // Pre:  This object is a defined Particle object
  //       pParticle is a defined Particle object
  // Post: RV = this object where this object now has
  //            mass = mass + pParticle.mass, position = the midpoint between
  //            this object and pParticle,
  //            velocity = velocity + pParticle.velocity and the
  //            radius = radius + pParticle.radius
  Particle operator + (const Particle & pParticle);

  // Pre:  This object is a defined Particle object
  //       pParticle is a defined Particle object
  // Post: RV = this object where mass = pParticle.mass,
  //            position = pParticle.position, velocity = pParticle.velocity,
  //            and radius = pParticle.radius
  Particle operator = (const Particle & pParticle);

  // Pre:  This object is a defined Particle object
  //       pParticle is a defined Particle object
  // Post: RV = true iff mass == pParticle.mass and radius = pParticle.radius
  //                 and velocity == pParticle.velocity
  bool operator == (const Particle & pParticle) const;

  // Pre:  This object is a defined Particle object
  //       pID is an int representing the ID of a Particle object
  // Post: RV = true iff ID == pID
  bool operator == (int pID) const;

  // Pre:  This object is a defined Particle object
  //       pID is an int object
  // Post: RV = true iff ID > pID
  bool operator > (int pID) const;

  // Pre:  stream is an ostream object
  //       pParticle is a defined Particle object
  // Post: RV = stream where stream contains the data from pParticle
  friend ostream & operator << (ostream & stream, const Particle & pParticle);

  // Pre:  file is an ifstream object
  //       pParticle is a defined Particle object
  // Post: RV = file
  //       pParticle contains the data from file
  friend ifstream & operator >> (ifstream & file, Particle & pParticle);

};

#endif
