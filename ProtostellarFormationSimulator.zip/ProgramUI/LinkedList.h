#ifndef included_linkedList
#define included_linkedList

#include "linkedNode.h"
#include "Exception.h"
#include <iostream>
using namespace std;

template <class T>
class linkedList {
  // CI: numElements is an integer n >= 0
  //     firstNode is a pointer to the first linkedNode<T> object or NULL

 private:
  linkedNode<T> * firstNode;
  int numElements;

 public:

  // Pre:
  // Post: This object has been constructed. firstNode = NULL
  //        and numElements = 0
  linkedList() {
    firstNode = NULL;
    numElements = 0;
  }

  // Pre:  pData is an object of type T
  // Post: This object has been constructed. firstNode points to a node
  //        containing pData and numElements = 1
  linkedList(T pData) {
    firstNode = new linkedNode<T>(pData);
    numElements = 1;
  }

  // Pre:  pList is a defined linkedList object
  // Post: This object is a deep copy of pString
  linkedList(const linkedList<T> & pList) {
    numElements = pList.numElements;
    linkedNode<T> * iterate = pList.firstNode;
    firstNode = new linkedNode<T>(iterate->getData());
    linkedNode<T> * prevNode = firstNode;
    for (int index = 1; index < numElements; index ++) {
      iterate = iterate->getNext();
      linkedNode<T> * copyNode = new linkedNode<T>(iterate->getData());
      prevNode->setNext(copyNode);
      prevNode = copyNode;
    }
  }      

  // Pre:  This object is a well defined linkedList object
  // Post: The attributes of this object have been reset and all allocated
  //        heap space has been returned
  ~linkedList<T> () {
    if (firstNode != NULL) {
      delete firstNode;
    }
  }

  // Pre:  This object is a well defined linkedList object
  // Post: RV = firstNode
  linkedNode<T> * getFirstNode() const {
    return(firstNode);
  }

  // Pre:  This object is a well defined linkedList object
  // Post: RV = numElements
  int getNumElements () const {
    return(numElements);
  }

  // Pre:  This object is a well defined linkedList object
  //       numElements = n
  //       pElement is a defined object of type T
  // Post: pElement has been added to the front of the list
  //        and numElements = n + 1
  void addToFront (T pElement) {
    linkedNode<T> * newNode = new linkedNode<T>(pElement);
    if (numElements != 0) {
      newNode->setNext(firstNode);
    }
    firstNode = newNode;
    numElements ++;
  }

  // Pre:  This object is a well defined linkedList object
  //       numElements = n
  //       pElements is a defined object of type T
  // Post: pElement has been added to the back of the list
  //        and numElements = n + 1
  void addToBack (T pElement) {
    linkedNode<T> * newNode = new linkedNode<T>(pElement);
    if (numElements != 0) {
      linkedNode<T> * pointerNode = firstNode;
      for (int index = 0; index < numElements - 1; index ++) {
	pointerNode = pointerNode->getNext();
      }
      pointerNode->setNext(newNode);
    }
    else {
      firstNode = newNode;
    }
  }

  // Pre:  This object is a defined linkedList object & numElements = n
  //       pElement is an object of type T
  //       pIndex is an integer 0 <= i <= numElements
  // Post: pElement has been added to the list as the index item
  void addToNthIndex (T pElement, int pIndex) {
    if ((pIndex >= 0) && (pIndex <= numElements)) {
      if (pIndex == 0) {
	addToFront(pElement);
      }
      else if (pIndex == numElements) {
	addToBack(pElement);
      }
      else {
	linkedNode<T> * newNode = new linkedNode<T>(pElement);
	linkedNode<T> * iterate = firstNode;
	for (int index = 1; index < pIndex; index ++) {
	  iterate = iterate->getNext();
	}
	newNode->setNext(iterate->getNext());
	iterate->setNext(newNode);
      }
    }
    else {
      throw(Exception((char *)"Invalid index."));
    }
  }

  // Pre:  This object is a defined linkedList object
  //       numElements = n
  //       pElement is an object of type T
  // Post: pElement has been added to the list according to sorted order
  //        and numElements = n + 1
  void addToList (T pElement) {
    linkedNode<T> * newNode = new linkedNode<T>(pElement);
    if (numElements != 0) {
      linkedNode<T> * pointerNode = firstNode;
      while (pElement > pointerNode->getData()) {
	pointerNode = pointerNode->getNext();
      }
      newNode->setNext(pointerNode->getNext());
      pointerNode->setNext(newNode);
    }
    else {
      firstNode = newNode;
    }
  }

  // Pre:  This object is a defined linkedList object
  //       pIndex is an integer n such that 0 <= n < numElements
  // Post: RV = the data stored at the pIndex node
  T getNthElement (int pIndex) {
    T nthElement;
    if ((pIndex < numElements) && (pIndex >= 0) && (numElements != 0)) {
      linkedNode<T> * iterate = firstNode;
      for (int index = 0; index < pIndex; index ++) {
	iterate = iterate->getNext();
      }
      nthElement = iterate->getData();
    }
    else {
      throw (Exception((char *)"Invalid index."));
    }
    return(nthElement);
  }

  // Pre:  This object is a defined linkedList object
  //       pData is an object of type T
  // Post: RV = linkedNode * that contains pData
  linkedNode<T> * getNodeData (const T & pData) {
    linkedNode<T> * iterate = firstNode;
    while (iterate->getData() != pData) {
      iterate = iterate->getNext();
    }
    return(iterate);
  }

  // Pre:  This object is a defined linkedList object
  //       pNode is a defined linkedNode<T> pointer object
  //       pIndex is an integer
  // Post: pNode is at index pIndex
  void moveNodeToNthIndex(linkedNode<T> * pNode, int pIndex) {
    int currIndex = pNode->getIndex();
    if (currIndex != pIndex) {
      linkedNode<T> * iterate;
      if (currIndex == 0) {
	firstNode = pNode->getNext();
      }
      else {
	// ASSERT: pNode is not the first node in the list
	iterate = firstNode;
	for (int index = 0; index < pNode->getIndex(); index ++) {
	  iterate = iterate->getNext();
	}
	// ASSERT: iterate is the node before pNode
	iterate->setNext(pNode->getNext());
      }
      linkedNode<T> * currentNext;
      if (pIndex > currIndex) {
	iterate = pNode->getNext();
	for (int index = currIndex + 1; index < pIndex; index ++) {
	  iterate = iterate->getNext();
	}
      }
      else {
	iterate = firstNode;
	for (int index = 1; index < pIndex; index ++) {
	  iterate = iterate->getNext();
	}
      }
      currentNext = iterate->getNext();
      iterate->setNext(pNode);
      pNode->setNext(currentNext);
      pNode->setIndex(pIndex);
      iterate = currentNext;
      int index = pIndex + 1;
      while (iterate != NULL) {
	iterate->setIndex(index);
	index ++;
	iterate = iterate->getNext();
      }
    }
  }
  
  // Pre:  This object is a defined linkedList object
  // Post: The first object in this list has been deleted
  void deleteFront() {
    if (numElements > 0) {
      linkedNode<T> * tempPointer = firstNode;
      firstNode = firstNode->getNext();
      tempPointer->setNext(NULL);
      delete tempPointer;
      numElements --;
    }
    else {
      throw (Exception((char *)"Invalid index."));
    }
  }

  // Pre:  This object is a defined linkedList object
  //       pIndex is an integer n such that 0 <= n < numElements
  // Post: The object at pIndex has been deleted
  void deleteNthElement(int pIndex) {
    if ((pIndex >= 0) && (pIndex < numElements) && (numElements != 0)) {
      if (pIndex == 0) {
	deleteFront();
      }
      else {
	linkedNode<T> * tempPointer;
	linkedNode<T> * iterate = firstNode;
	for (int index = 0; index < pIndex - 1; index ++) {
	  iterate = iterate->getNext();
	}
	tempPointer = iterate->getNext();
	iterate->setNext(tempPointer->getNext());
	tempPointer->setNext(NULL);
	delete tempPointer;
	numElements --;
      }
    }
    else {
      throw (Exception((char *)"Invalid index."));
    }
  }

  // Pre:  This object is a well defined linkedList<T> object
  // Post: The last object in this list has been deleted
  void deleteBack () {
    deleteNthElement(numElements - 1);
  }

  // Pre:  This object is a well defined linkedList<T> object
  //       pNode is a linkedNode<T> object pointer in the list
  // Post: pNode has been deleted from the list
  void deleteNode(linkedNode<T> * pNode) {
    int index = pNode->getIndex();
    deleteNthElement(index);
  }

  // Pre:  This object is a well defined linkedList<T> object
  // Post: The first element has been returned and deleted
  T TopAndPop () {
    T element = firstNode->getData();
    deleteFront();
    return(element);
  }

  // Pre:  This object is a well defined linkedList<T> object
  //       pData is an object of type T
  // Post: RV = true iff pData is in this list
  bool isIn(const T & pData) const {
    bool inList = false;
    linkedNode<T> * iterate = firstNode;
    while((iterate != NULL) && (!inList)) {
      if (iterate->getData() == pData) {
	inList = true;
      }
      else {
	iterate = iterate->getNext();
      }
    }
    return(inList);
  }

  // Pre:  This object is a well defined linkedList<T> object
  //       pData is an object of type T
  // Post: If pData was not in this list, it was added to the back of the
  //        list.
  void notInPlacement(T pData) {
    bool inList = false;
    bool endOfList = false;
    linkedNode<T> * iterate = firstNode;
    while((!endOfList) && (!inList)) {
      if (iterate->getData() == pData) {
	inList = true;
      }
      else if (iterate->getNext() == NULL) {
	endOfList = true;
      }
      else {
	iterate = iterate->getNext();
      }
    }
    if (!inList) {
      linkedNode<T> * newNode = new linkedNode<T>(pData);
      iterate->setNext(newNode);
      numElements ++;
    }
  }
  
  // Pre:  This object is a well defined linkedList<T> object
  // Post: RV = true iff numElements = 0
  bool isEmpty() const {
    return(numElements == 0);
  }

  // Pre:  stream is a defined ostream object
  //       pList is a defined linkedList<T> object
  // Post: RV = stream which contains the data from pList
  friend ostream & operator << (ostream & stream, const linkedList<T> & pList) {
    linkedNode<T> * iterate = pList.firstNode;
    for (int index = 0; index < pList.numElements; index ++) {
      stream << *iterate << " -> ";
      iterate = iterate->getNext();
    }
    stream << "NULL";
    return(stream);
  }

};

#endif
    
