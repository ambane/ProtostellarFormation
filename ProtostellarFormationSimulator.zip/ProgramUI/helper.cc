#include "helper.h"
#include <string>

const int DECIMAL = 10;

std::string intToChar(int number) {
    int modInt;
    std::string thisChar;
    std::string newString;
    int prepend = 0;
    if (number == 0) {
      newString = newString + '0';
    }
    while (number != 0) {
      modInt = number % DECIMAL;
      thisChar += char(modInt + int('0'));
      newString.insert(prepend, thisChar);
      thisChar.erase(0);
      number = number / DECIMAL;
    }
    return(newString);
}
