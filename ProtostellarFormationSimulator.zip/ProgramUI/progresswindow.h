#ifndef PROGRESSWINDOW_H
#define PROGRESSWINDOW_H

#include <QWidget>

namespace Ui {
class ProgressWindow;
}

class ProgressWindow : public QWidget
{
    Q_OBJECT

public:
    explicit ProgressWindow(QWidget *parent = 0);
    ~ProgressWindow();
    void processedCount(int numProcessed);
    void leftCount(int numLeft);

private:
    Ui::ProgressWindow *ui;
};

#endif // PROGRESSWINDOW_H
