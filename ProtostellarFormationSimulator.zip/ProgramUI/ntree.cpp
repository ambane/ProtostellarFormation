#include "ntree.h"

NTree::NTree()
{

}

NTree::NTree(int pDivisions, int pSize, ParticleArray * pElements) {
    numDivisions = pDivisions;
    size = pSize;
    elements = pElements;
    Vector<long long, long long, long long> * pPoint =
            new Vector<long long, long long, long long>();
    root = new NTreeNode(numDivisions, size, pPoint, elements);
    root->divideSpace();
}

NTreeNode * NTree::getRoot() {
    return(root);
}
