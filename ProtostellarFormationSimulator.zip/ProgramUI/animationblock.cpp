#include "animationblock.h"

AnimationBlock::AnimationBlock()
{
    massSum = 0;
}

ostream & operator << (ostream & stream, const AnimationBlock & pBlock) {
    stream << pBlock.particles << pBlock.massSum << endl;
    return(stream);
}

