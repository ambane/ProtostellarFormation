#ifndef included_IOConstants
#define included_IOConstants

#define MAX_VEL 40000
#define AU_TO_KM 149600000

#endif
