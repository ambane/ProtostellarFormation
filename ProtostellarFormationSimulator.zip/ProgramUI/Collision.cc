#include "Collision.h"
#include "Particle.h"
#include "ObjectArray.h"
#include "ParticleArray.h"
#include "Pair.h"
#include "LineSegment.h"
#include "Octree.h"
#include "OctNode.h"
#include "Exception.h"
#include <iostream>
using namespace std;

// Pre:  particleArray is an objectArray<Particle*> passed by ref as a const
//       segmentArray is an objectArray<LineSegment*> passed by reference
// Post: For every particle in particleArray, a LineSegment * object has
//        been created with points representing the starting and ending position
//        of the Particle for the timestep
void createSegmentArray (ParticleArray * particleArray,
			 ObjectArray<LineSegment> & segmentArray) {
  int index = 0;
  Particle * currParticle;
  while ((index < particleArray->getNumElements()) &&
	 (!particleArray->getIthObject(index)->getIsNull())) {
    currParticle = particleArray->getIthObject(index);
    if (currParticle != NULL) {
      LineSegment currSeg(*currParticle);
      segmentArray.addObject(currSeg);
      index ++;
    }
    else {
      throw (Exception((char *)"CurrParticle NULL in createSegmentArray."));
    }
  }
}

// Pre:  segmentArray is an objectArray<LineSegment*> passed by reference
//       intersectArray is an objectArray<Pair<Particle*, Particle*> > passed
//        by reference
//       ParticleArray is an objectArray<Particle*> object passed by reference
// Post: Every LineSegment in segmentArray has been compared to every other
//        LineSegment to find any intersection. If they intersect, the
//        respective Particle objects represented by the LineSegment objects
//        have been added to intersectArray
void createIntersectArray (const ObjectArray<LineSegment> & segmentArray,
			   ObjectArray<Pair<Pair<Particle*, Particle*>,
               Vector<long long,long long,long long> > > & intersectArray,
			   ParticleArray * particleArray) {
  Vector<long long,long long,long long> currIntersection;
  bool doIntersect;
  Particle * currParticle;
  Particle * compareParticle;
  LineSegment currSegment;
  LineSegment compareSegment;
  for (int index = 0; index < segmentArray.getNumElements(); index ++) {
    currParticle = particleArray->getIthObject(index);
    if (currParticle != NULL) {
      currSegment = segmentArray.getIthObject(index);
      for (int subIndex = index + 1; subIndex < segmentArray.getNumElements();
	   subIndex++) {
	compareParticle = particleArray->getIthObject(subIndex);
	if (compareParticle != NULL) {
	  compareSegment = segmentArray.getIthObject(subIndex);
	  currSegment.findIntersection(compareSegment, currIntersection,
				       doIntersect);
	  if (doIntersect) {
	    Pair<Particle *, Particle *> partPair(currParticle,
						  compareParticle);
        Pair<Pair<Particle*, Particle*>, Vector<long long,long long,long long> >
	      pair(partPair, currIntersection);
	    intersectArray.addObject(pair);
	    doIntersect = false;
	  }
	}
	else {
	  throw(Exception((char *)"CompareParticle NULL in createIntersect"));
	}
      }
    }
    else {
      throw(Exception((char *)"CurrParticle NULL in createIntersect"));
    }
  }
}

// Pre:  particle1 and particle2 are pointers to Particle objects
//       intersection is a Vector<float, float, float> object
// Post: RV = true iff the particle1 and particle2 are within the radius
//            of the other at the same time
bool determineTime (const Particle * particle1, const Particle * particle2,
            const Vector<long long, long long, long long> &
                    intersection) {
  bool sameTime = false;
  float radius1 = particle1->getRadius();
  float radius2 = particle2->getRadius();
  float particle1Time1 = particle1->calculateTime(intersection + radius1);
  float particle1Time2 = particle1->calculateTime(intersection - radius1);
  float particle2Time1 = particle2->calculateTime(intersection + radius2);
  float particle2Time2 = particle2->calculateTime(intersection - radius2);
  float tempTime;
  if (particle1Time1 > particle1Time2) {
    tempTime = particle1Time1;
    particle1Time1 = particle1Time2;
    particle1Time2 = tempTime;
  }
  if (particle2Time1 > particle2Time2) {
    tempTime = particle2Time1;
    particle2Time1 = particle2Time2;
    particle2Time2 = tempTime;
  }
  if (((particle1Time1 >= particle2Time1) &&
       (particle1Time1 <= particle2Time2)) ||
      ((particle1Time2 >= particle2Time1) &&
       (particle1Time2 <= particle2Time2)) ||
      ((particle2Time1 >= particle1Time1) &&
       (particle2Time1 <= particle1Time2)) ||
      ((particle2Time2 >= particle1Time1) &&
       (particle2Time2 <= particle1Time2))) {
    sameTime = true;
  }
  return(sameTime);
}

// Pre:  intersectArray is an ObjectArray<Pair> object passed by reference
//        where the Pair is a Pair of Particle * and a
//        Vector<float, float, float> representing the point of intersection
//        between the line segments of the pair of particles.
//       timeArray is an ObjectArray<int> object passed by reference
// Post: intersectArray contains the pairs of Particles that reach the
//        point of intersection at the same time and timeArray contains
//        the time they meet.
void findCollisions (ObjectArray<Pair<Pair<Particle*, Particle*>,
             Vector<long long, long long, long long> > > &
                     intersectArray,
		     ObjectArray<Pair<Pair<Particle*, Particle*>, int> > &
             collisions) {
  int time;
  int collisionsIndex;
  Pair<Pair<Particle*, Particle*>, Vector<long long, long long,
          long long> > currPair;
  Pair<Particle *, Particle*> currParticlePair;
  Particle * particle1;
  Particle * particle2;
  Vector<long long, long long, long long> intersection;
  bool sameTime;
  for (int index = 0; index < intersectArray.getNumElements(); index ++) {
    currPair = intersectArray.getIthObject(index);
    currParticlePair = currPair.getFirst();
    particle1 = currParticlePair.getFirst();
    particle2 = currParticlePair.getSecond();
    if (particle1 != NULL) {
      if (particle2 != NULL) {
	intersection = currPair.getSecond();
	sameTime = determineTime(particle1, particle2, intersection);
	if (sameTime) {
	  collisionsIndex = 0;
	  time = particle1->calculateTime(intersection);
	  Pair<Pair<Particle*, Particle*>, int> newPair(currParticlePair, time);
	  if (collisions.getNumElements() != 0) {
	    while (time >
		   (collisions.getIthObject(collisionsIndex).getSecond())) {
	      collisionsIndex ++;
	    }
	  }
	  collisions.addObjectToIndex(newPair, collisionsIndex);
	}
      }
      else {
	throw(Exception((char*)"Particle2 NULL in findCollisions."));
      }
    }
    else {
      throw(Exception((char*)"Particle1 NULL in findCollisions."));
    }
  }
}

// Pre:  particleArray is a ParticleArray object passed by pointer
// Post: All collisions occuring during the timestep have been found and
//        processed
void runCollisions(ParticleArray * particleArray, int & numCollisions, int mergeFactor, ofstream & collisionLocation) {
  Particle * particle1;
  Particle * particle2;
  Vector<long long, long long, long long> * collisionPosition;
  bool allCollisionsProcessed = false;
  conglomerate(particleArray, numCollisions, mergeFactor, collisionLocation);
  while (!allCollisionsProcessed) {
    ObjectArray<LineSegment> segmentArray;
    int currentTime;
    ObjectArray<Pair<Pair<Particle *, Particle *>,
           Vector<long long, long long, long long> > > intersectArray;
    ObjectArray<Pair<Pair<Particle *, Particle *>, int> > collisions;
    createSegmentArray(particleArray, segmentArray);
    createIntersectArray(segmentArray, intersectArray, particleArray);
    findCollisions(intersectArray, collisions);
    int index = 0;
    if (collisions.getNumElements() != 0) {
      currentTime = collisions.getIthObject(0).getSecond();
      while ((collisions.getNumElements() != 0) &&
	     (collisions.getIthObject(0).getSecond() == currentTime)) {
	particle1 = collisions.getIthObject(0).getFirst().getFirst();
	particle2 = collisions.getIthObject(0).getFirst().getSecond();
	particle1->setPositionWithTime(currentTime);
	particle2->setPositionWithTime(currentTime);
	*particle1 = *particle1 + *particle2;
    collisionPosition = particle1->getPosition();
    collisionLocation << collisionPosition->getX() << ' ' << collisionPosition->getY() << ' '
                      << collisionPosition->getZ() << ' ' << particle1->getMass() << endl;
	particle2->setIsNull(true);
	collisions.deleteByIndex(0);
	numCollisions ++;
	index ++;
      }
      particleArray->moveNullParticles();
      if (collisions.getNumElements() == 0) {
	allCollisionsProcessed = true;
      }
    }
    else {
      allCollisionsProcessed = true;
    }
  }
}

// Pre:  particleArray is a ParticleArray object passed by pointer
// Post: Any particles within DISTANCE radii of each other have been
//        combined
void conglomerate(ParticleArray * particleArray, int & numCollisions, int mergeFactor, ofstream & collisionLocation) {
  int index = 0;
  Particle * currParticle;
  Particle * compareParticle;
  int convergeLength;
  int distance;
  int subIndex;
  Vector<long long, long long, long long> * collisionPosition;
  while ((index < particleArray->getNumElements() - 2) &&
	 (!particleArray->getIthObject(index)->getIsNull())) {
    currParticle = particleArray->getIthObject(index);
    convergeLength = currParticle->getRadius() * mergeFactor;
    subIndex = index + 1;
    while ((subIndex < particleArray->getNumElements()) &&
	   (!particleArray->getIthObject(subIndex)->getIsNull())) {
      compareParticle = particleArray->getIthObject(subIndex);
      distance = currParticle->calculateDistance(*compareParticle);
      if (distance <= convergeLength) {
	*currParticle = *currParticle + *compareParticle;
          collisionPosition = currParticle->getPosition();
          collisionLocation << collisionPosition->getX() << ' ' << collisionPosition->getY() << ' '
                            << collisionPosition->getZ() << ' ' << currParticle->getMass() << endl;
	compareParticle->setIsNull(true);
	particleArray->moveNullParticles();
	numCollisions ++;
      }
      else {
	subIndex ++;
      }
    }
    index ++;
  }
}
