#ifndef GENERATEWINDOW_H
#define GENERATEWINDOW_H

#include <QWidget>

namespace Ui {
class GenerateWindow;
}

class GenerateWindow : public QWidget
{
    Q_OBJECT

public:
    explicit GenerateWindow(QWidget *parent = 0);
    ~GenerateWindow();

private:
    Ui::GenerateWindow *ui;

private slots:
    void handleOK();

};

#endif // GENERATEWINDOW_H
