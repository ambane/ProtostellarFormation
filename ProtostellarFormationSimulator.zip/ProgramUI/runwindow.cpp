#include "runwindow.h"
#include "ui_runwindow.h"
#include "IOFile.h"
#include "ParticleArray.h"
#include "ProcessTimestep.h"
#include "Octree.h"
#include "helper.h"
#include <QtConcurrent/qtconcurrentrun.h>
#include <sys/times.h>
#include <unistd.h>
const int DECIMAL = 10;

RunWindow::RunWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::RunWindow)
{
    ui->setupUi(this);
    numTimesteps = 0;
    numTimestepsRun = 0;
    connect(ui->ok, SIGNAL(clicked(bool)), this, SLOT(handleOK()));
    connect(ui->cancel, SIGNAL(clicked(bool)), this, SLOT(close()));
}

RunWindow::~RunWindow()
{
    delete ui;
}

void RunWindow::handleOK() {
    this->hide();
    ok = true;
    numTimesteps = ui->Timesteps->value();
    timestep = ui->TimestepDuration->value();
    minParticles = ui->ParticlesPerOctant->value();
    minLength = ui->MinimumLength->value();
    stepsBetweenWrite = ui->WriteNum->value();
    mergeFactor = ui->merge->value();
    writeParticles = ui->particleWrite->isChecked();
    fileWithPath = ui->lineEdit->text().toStdString();
    getPath(fileWithPath, file, path);
    time = path + "Time";
    collision = path + "Collision";
    location = path + "CollisionLocation";
    escaped = path + "EscapedParticles";
    process();
}

void RunWindow::process() {
    long ticksPerSecond = sysconf(_SC_CLK_TCK);
    struct tms timeStructure;
    ofstream TimeFile(time.data());
    ofstream CollisionFile(collision.data());
    ofstream CollisionLocationFile(location.data());
    ofstream EscapedParticleFile(escaped.data());
    int numCollisions = 0;
    int intFileIndex = 0;
    string stringFileIndex;
    int writeNumber = (numTimesteps/stepsBetweenWrite);
    ParticleArray * ParticleStore = new ParticleArray();
    Particle * currParticle;
    int numParticles;
    long long spaceSize;
    readFile(fileWithPath.data(), ParticleStore, numParticles, spaceSize);
    Octree spaceTree(spaceSize, numParticles, ParticleStore,
                     minLength, minParticles);
    for (int writeIndex = 0; writeIndex < writeNumber; writeIndex ++) {
         time_t startTimeStepTime = times(&timeStructure);
        for (int index = 0; index < stepsBetweenWrite; index ++) {
            processTimestep(spaceTree, numCollisions, timestep, mergeFactor, CollisionLocationFile, EscapedParticleFile);
            numTimestepsRun ++;
        }
        if (writeParticles) {
            particle = fileWithPath;
            stringFileIndex = intToChar(intFileIndex);
            particle = particle + stringFileIndex;
            ofstream particleFile(particle.data());
            particleFile << ParticleStore->getNumElements() << endl;
            particleFile << spaceSize << endl;
            for (int outputIndex = 0; outputIndex < ParticleStore->getNumElements();
                 outputIndex ++) {
                currParticle = ParticleStore->getIthObject(outputIndex);
                particleFile << *currParticle;
            }
            particleFile.close();
            intFileIndex ++;
        }
        time_t endTimeStepTime = times(&timeStructure);
        long TimeStepTime = ((endTimeStepTime - startTimeStepTime) /
                 ticksPerSecond);
        TimeFile << TimeStepTime << ' ';
        CollisionFile << numCollisions << ' ';
        numCollisions = 0;
    }
    if (!writeParticles) {
        particle = fileWithPath + '0';
        ofstream particleFile(particle.data());
        particleFile << ParticleStore->getNumElements() << endl;
        particleFile << spaceSize << endl;
        for (int outputIndex = 0; outputIndex < ParticleStore->getNumElements(); outputIndex++) {
            currParticle = ParticleStore->getIthObject(outputIndex);
            particleFile << *currParticle;
        }
        particleFile.close();
    }
    CollisionFile.close();
    TimeFile.close();
    CollisionLocationFile.close();
    EscapedParticleFile.close();
}

void RunWindow::getPath(const std::string &fileWithPath,
                        string & fileName, string & filePath) {
    char search('/');
    int searchIndex = fileWithPath.rfind(search) + 1;
    filePath = fileWithPath;
    fileName = fileWithPath;
    filePath = filePath.erase(searchIndex);
    fileName = fileName.erase(0, searchIndex);
}
