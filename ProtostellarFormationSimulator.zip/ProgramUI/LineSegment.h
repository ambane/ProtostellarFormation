#ifndef included_LineSegment
#define included_LineSegment

#include "Vector.h"
#include "Particle.h"
#include <iostream>
using namespace std;

class LineSegment {
  //CI:  start and end are defined Vector<long long, long long, long long> objects
  //      the start and end coordinates of the line segment
  //     xDenom, yDenom, and zDenom are long long objects representing the
  //      denominator of the x, y, and z values respectively in the
  //      symmetric vector equation of a line.
  //     ID is an integer representing the ID of the LineSegment
  
 private:

  int ID;
  Vector<long long, long long, long long> start;
  Vector<long long, long long, long long> end;

 public:

  // Pre: 
  // Post: This object has been constructed. ID = 0. start and end have been
  //        constructed and are both <0, 0, 0> and xDenom, yDenom, and zDenom
  //        are all 1
  LineSegment ();

  // Pre:  pID is an integer
  //       pStart and pEnd are Vector<long long, long long, long long> objects
  // Post: ID = pID, start = pStart, end = pEnd, and xDenom, yDenom, and zDenom
  //        have been set
  LineSegment (int pID, const Vector<long long, long long, long long> & pStart,
           const Vector<long long, long long, long long> & pEnd);

  // Pre:  pParticle is a Particle passed as a const by reference
  // Post: start = pParticle.getPosition(),
  //        end = start + pParticle.getVelocity(),
  //        and ID = pParticle.ID
  LineSegment (const Particle & pParticle);

  // Pre:  pID is an integer
  //       pStart and pEnd are Vector<long long, long long, long long> objects
  // Post: ID = pID, start = pStart, end = pEnd, and xDenom, yDenom, and zDenom
  //        have been set
  void setData(int pID, const Vector<long long, long long, long long> & pStart,
           const Vector<long long, long long, long long> & pEnd);

  // Pre:  This object is a defined LineSegment object
  // Post: RV = ID
  int getID() const {return(ID);}

  // Pre:  This object is a defined LineSegment object
  // Post: RV = start
  Vector<long long, long long, long long> getStart() const {return(start);};

  // Pre:  This object is a defined LineSegment object
  // Post: RV = end
  Vector<long long, long long, long long> getEnd() const {return(end);};

  // Pre:  This object is a defined LineSegment object
  // Post: RV = start.X
  long long getStartX() const {return(start.getX());}

  // Pre:  This object is a defined LineSegment object
  // Post: RV = start.Y
  long long getStartY() const {return(start.getY());}

  // Pre:  This object is a defined LineSegment object
  // Post: RV = start.Z
  long long getStartZ() const {return(start.getZ());}

// Pre:  This object is a defined LineSegment object
  // Post: RV = end.X
  long long getEndX() const {return(end.getX());}

  // Pre:  This object is a defined LineSegment object
  // Post: RV = end.Y
  long long getEndY() const {return(end.getY());}

  // Pre:  This object is a defined LineSegment object
  // Post: RV = end.Z
  long long getEndZ() const {return(end.getZ());}
  
  // Pre:  This object is a well defined LineSegment object and is const
  //       pSegment is a well defined LineSegment object that is passed by
  //        reference as a const
  // Post: RV = the Vector<long long, long long, long long> object that represents the point
  //            of intersection between this object and pSegment
  void findIntersection(const LineSegment & pSegment,
            Vector<long long, long long, long long> & intersection,
			bool & intersect) const;

  // Pre:  This object is a well defined LineSegment object
  //       pVector is a defined Vector object passed by reference as a const
  // Post: RV = true iff pVector is between start and end
  bool isBetween(const Vector<long long, long long, long long> & pVector) const;
  
  // Pre:  This object is a well defined LineSegment object
  //       pSegment is a defined LineSegment object
  // Post: RV = this where all member data of this segment = pSegment
  LineSegment operator = (const LineSegment & pSegment);

  // Pre:  This object is a well defined LineSegment object
  //       pSegment is a defined LineSegment object
  // Post: RV = true iff start.x < pSegment.start.x
  bool operator < (const LineSegment & pSegment) const;
  
  // Pre:  This object is a well defined LineSegment object
  //       pSegment is a defined LineSegment object
  // Post: RV = true iff start.x > pSegment.start.x
  bool operator > (const LineSegment & pSegment) const;
  
  // Pre:  This object is a well defined LineSegment object
  //       pSegment is a defined LineSegment object
  // Post: RV = true iff start == pSegment.start and end = pSegment.end
  bool operator == (const LineSegment & pSegment) const;

  // Pre:  This object is a well defined LineSegment object
  //       pSegment is a defined LineSegment object
  // Post: RV = true iff !(this == pSegment)
  bool operator != (const LineSegment & pSegment) const;

  // Pre:  This object is a well defined LineSegment object
  //       pSegment is a defined LineSegment object
  // Post: RV = true iff this < pSegment or this == pSegment
  bool operator <= (const LineSegment & pSegment) const;

  // Pre:  This object is a well defined LineSegment object
  //       pSegment is a defined LineSegment object
  // Post: RV = true iff this > pSegment or this == pSegment
  bool operator >= (const LineSegment & pSegment) const;
  
  // Pre:  stream is a defined ostream object
  //       pSegment is a defined LineSegment object passed by
  //       reference as a const
  // Post: RV = stream which contains the data from pSegment
  friend ostream & operator << (ostream & stream, const LineSegment & pSegment);

};

#endif
