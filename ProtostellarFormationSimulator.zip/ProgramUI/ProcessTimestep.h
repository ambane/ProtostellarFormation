#ifndef included_ProcessTimestep
#define included_ProcessTimestep

#include "Gravity.h"
#include "Collision.h"
#include "Octree.h"
#include "OctNode.h"
#include <fstream>
using namespace std;

// Pre:  spaceTree is an Octree passed by reference
//       numCollisions is an int passed by reference
// Post: All collisions during the timestep for all particles have been found
//        and processed
void processTimestep(Octree & spaceTree, int & numCollisions, double timestepDuration, int mergeFactor, ofstream & collisionLocation, ofstream & escapedParticles);

// Pre:  pNode is a pointer to an OctNode<Particle*> object
// Post: All gravitational forces have been calculated for any leaves below
//        pNode or, if pNode is a leaf, the gravitational forces have been
//        calculated for it and its siblings
void findLeaves(OctNode * pNode, int & numCollisions, double timestepDuration, int mergeFactor, ofstream & collisionLocation);

// Pre:  elements is a pointer to a defined ParticleArray object
//       size is an long long representing the total size of the space
// Post: all Particle* objects that are outside of the bounds have been made NULL
void findEscapedParticles(ParticleArray * elements, long long size, int & numEscaped);

#endif
