#ifndef included_linkedNode
#define included_linkedNode

#include <iostream>
using namespace std;

template <class T>
class linkedNode {
  // CI:  data is a defined object of type T
  //      next is NULL or is a pointer to the next linkedNode object
  //       in the list
  //      index is the place in the list occupied by this node

 private:

  T data;
  linkedNode<T> * next;
  int index;

 public:

  // Pre:
  // Post: data is garbage and next = NULL and index = 0
  linkedNode () {
    next = NULL;
    index = 0;
  }

  // Pre:  pData is a defined object of type T
  // Post: data = pData and next = NULL and index = 0
  linkedNode (T pData) {
    data = pData;
    next = NULL;
    index = 0;
  }

  // Pre:  This object is a defined linkedNode object
  // Post: all heap space has been deallocated
  ~linkedNode () {
    if (next != NULL) {
      delete next;
    }
  }

  // Pre:  This object is a defined linkedNode object
  // Post: RV = next
  linkedNode<T> * getNext() const {
    return(next);
  }

  // Pre:  This object is a defined linkedNode object
  // Post: RV = data
  T getData() const {
    return(data);
  }

  // Pre:  This object is a defined linkedNode object
  // Post: RV = index
  int getIndex() const {
    return(index);
  }

  // Pre:  This object is a defined linkedNode object
  //       pNode is a pointer to a linkedNode object
  // Post: next = pNode
  void setNext(linkedNode<T> * pNode) {
    next = pNode;
  }

  // Pre:  This object is a defined linkedNode object
  //       pData is a defined object of type T
  // Post: data = pData
  void setData(T pData) {
    data = pData;
  }

  // Pre:  This object is a defined linkedNode object
  //       pIndex is an int
  // Post: index = pIndex
  void setIndex(int pIndex) {
    index = pIndex;
  }

  // Pre:  This object is a well defined linkedNode object
  //       pNode is a defined linkedNode object
  // Post: This object is a deep copy of pNode
  linkedNode<T> * operator = (const linkedNode<T> & pNode) {
    linkedNode<T> * returnNode = new linkedNode<T>(pNode.data);
    index = pNode.index;
    returnNode->setNext(pNode.next);
    return(returnNode);
  }

  // Pre:  This object is a well defined linkedNode object
  //       pNode is a defined linkedNode object
  // Post: RV = true iff data < pNode.data
  bool operator < (const linkedNode<T> & pNode) const {
    return(data < pNode.data);
  }

  // Pre:  This object is a well defined linkedNode object
  //       pNode is a defined linkedNode object
  // Post: RV = true iff data > pNode.data
  bool operator > (const linkedNode<T> & pNode) const {
    return(data > pNode.data);
  }

  // Pre:  This object is a well defined linkedNode object
  //       pNode is a defined linkedNode object
  // Post: RV = true iff data == pNode.data
  bool operator == (const linkedNode<T> & pNode) const {
    return(data == pNode.data);
  }

  // Pre:  stream is a defined ostream object
  //       pNode is a defined linkedNode object
  // Post: RV = stream which contains pNode.data
  friend ostream & operator << (ostream & stream, const linkedNode<T> & pNode) {
    stream << pNode.data;
    return(stream);
  }

};

#endif
