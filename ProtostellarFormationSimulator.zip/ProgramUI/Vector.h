#ifndef included_Vector
#define included_Vector

#include <math.h>
#include <iostream>
#include <fstream>
using namespace std;

template <class T1, class T2, class T3>
class Vector {
  // CI: x_coord, y_coord, & z_coord are of type T1, T2, and T3 respectively
  //     For all operations between two Vector objects, the types must be the
  //      same, i.e. if vector1 is of type <int, int, int>, vector2 must also
  //      be of type <int, int, int> if any operations are to be performed
  //      between them.

 protected:
  T1 x_coord;
  T2 y_coord;
  T3 z_coord;

 public:

  // Pre:
  // Post: This object is a vector with coordinates <0, 0, 0>
  Vector<T1, T2, T3>() {
    x_coord = y_coord = z_coord = 0;
  }

  // Pre:  x_val, y_val, and z_val are objects of type T
  // Post: x_coord = x_val, y_coord = y_val, and z_coord = z_val
  Vector<T1, T2, T3> (T1 x_val, T2 y_val, T3 z_val) {
    x_coord = x_val;
    y_coord = y_val;
    z_coord = z_val;
  }

  // Pre:  This object is a defined Vector object
  // Post: RV = x_coord
  T1 getX () const {
    return(x_coord);
  }

  // Pre:  This object is a defined Vector object
  // Post: RV = y_coord
  T2 getY () const {
    return(y_coord);
  }

  // Pre:  This object is a defined Vector object
  // Post: RV = z_coord
  T3 getZ () const {
    return(z_coord);
  }

  // Pre:  This object is a defined Vector object
  //       x_val is an object of type T
  // Post: x_coord = x_val
  void setX (T1 x_val) {
    x_coord = x_val;
  }

  // Pre:  This object is a defined Vector object
  //       y_val is an object of type T
  // Post: y_coord = y_val
  void setY (T2 y_val) {
    y_coord = y_val;
  }

  // Pre:  This object is a defined Vector object
  //       z_val is an object of type T
  // Post: z_coord = z_val
  void setZ (T3 z_val) {
    z_coord = z_val;
  }

  // Pre:  This object is a defined Vector object
  //       x_val is of type T1, y_val is of type T2, and z_val is of type T3
  // Post: x_coord = x_val, y_coord = y_val, and z_coord = z_val
  void setCoordinates(T1 x_val, T2 y_val, T3 z_val) {
    x_coord = x_val;
    y_coord = y_val;
    z_coord = z_val;
   }

  // Pre:  This object is a defined Vector object
  //       pVector is a defined Vector object
  // Post: RV = the float representing the distance between this object
  //             and pVector
  unsigned long long findDistance(const Vector & pVector) const {
    unsigned long long x_squared;
    unsigned long long y_squared;
    unsigned long long z_squared;
    if (x_coord > pVector.x_coord) {
        x_squared = pow((x_coord - pVector.x_coord), 2);
    }
    else {
        x_squared = pow((pVector.x_coord - x_coord), 2);
    }
    if (y_coord > pVector.y_coord) {
        y_squared = pow((y_coord - pVector.y_coord), 2);
    }
    else {
        y_squared = pow((pVector.y_coord - y_coord), 2);
    }
    if (z_coord > pVector.z_coord) {
        z_squared = pow((z_coord - pVector.z_coord), 2);
    }
    else {
        z_squared = pow((pVector.z_coord - z_coord), 2);
    }
    unsigned long long distance = sqrt(x_squared + y_squared + z_squared);
    return(distance);
  }

  // Pre:  This object is a defined Vector object representing <x, y, z>
  //       pVector is a defined Vector object representing <x1, y1, z1>
  // Post: RV = true iff x > x1, y > y1, and z > z1
  bool operator > (const Vector<T1, T2, T3> & pVector) const {
    return((x_coord > pVector.x_coord) && (y_coord > pVector.y_coord) &&
	   (z_coord > pVector.z_coord));
  }

  // Pre:  This object is a defined Vector object representing <x, y, z>
  //       pVector is a defined Vector object representing <x1, y1, z1>
  // Post: RV = true iff x < x1, y < y1, and z < z1
  bool operator < (const Vector<T1, T2, T3> & pVector) const {
    return((x_coord < pVector.x_coord) && (y_coord < pVector.y_coord) &&
	   (z_coord < pVector.z_coord));
  }  

  //Pre:  This object is a defined Vector object representing <x, y, z>
  //       pVector is a defined Vector object representing <x1, y1, z1>
  // Post: RV = true iff x < x1 or x == x1, y < y1 or y == y1, and z < z1
  //             or z == z1
  bool operator <= (const Vector<T1, T2, T3> & pVector) const {
    return(((x_coord < pVector.x_coord) || (x_coord == pVector.x_coord)) &&
	   ((y_coord < pVector.y_coord) || (y_coord == pVector.y_coord)) &&
	   ((z_coord < pVector.z_coord) || (z_coord == pVector.z_coord)));
  }
  
  // Pre:  This object is a defined Vector object representing <x, y, z>
  //       pVector is a defined Vector object representing <x1, y1, z1>
  // Post: RV = true iff x > x1 or x == x1, y > y1 or y == y1, and z > z1
  //             or z == z1
  bool operator >= (const Vector<T1, T2, T3> & pVector) const {
    return(((x_coord > pVector.x_coord) || (x_coord == pVector.x_coord)) &&
	   ((y_coord > pVector.y_coord) || (y_coord == pVector.y_coord)) &&
	   ((z_coord > pVector.z_coord) || (z_coord == pVector.z_coord)));
  }
  
  // Pre:  This object is a defined Vector object representing <x, y, z>
  //       pVector is a defined Vector object representing <x1, y1, z1>
  // Post: RV = true iff x == x1, y == y1, and z == z1
  bool operator == (const Vector<T1, T2, T3> & pVector) const {
    return((x_coord == pVector.x_coord) && (y_coord == pVector.y_coord) &&
	   (z_coord == pVector.z_coord));
  }

  // Pre:  This object is a defined Vector object
  //       pVector is a defined Vector object representing <x, y, z>
  // Post: RV = this object, representing a hard copy of pVector
  Vector<T1, T2, T3> operator = (const Vector<T1, T2, T3> & pVector) {
    x_coord = pVector.x_coord;
    y_coord = pVector.y_coord;
    z_coord = pVector.z_coord;
    return(*this);
  }

  // Pre:  This object is a defined Vector object representing <x, y, z>
  //       pVector is a defined Vector object representing <x1, y1, z1>
  // Post: RV = a new Vector representing <x + x1, y + y1, z + z1>
  Vector<T1, T2, T3> operator + (const Vector<T1, T2, T3> & pVector) const {
    Vector<T1, T2, T3> sum;
    sum.x_coord = x_coord + pVector.x_coord;
    sum.y_coord = y_coord + pVector.y_coord;
    sum.z_coord = z_coord + pVector.z_coord;
    return(sum);
  }

  // Pre:  This object is a defined Vector object representing <x, y, z>
  //       pVector is a defined Vector object representing <x1, y1, z1>
  // Post: RV = this representing <x + x1, y + y1, z + z1>
  Vector<T1, T2, T3> operator += (const Vector<T1, T2, T3> & pVector) {
    x_coord += pVector.x_coord;
    y_coord += pVector.y_coord;
    z_coord += pVector.z_coord;
    return(*this);
  }

  // Pre:  This object is a defined Vector object representing <x, y, z>
  //       pVector is a defined Vector object representing <x1, y1, z1>
  // Post: RV = a new Vector representing <x - x1, y - y1, z - z1>
  Vector<T1, T2, T3> operator - (const Vector<T1, T2, T3> & pVector) const {
    Vector<T1, T2, T3> difference;
    difference.x_coord = x_coord - pVector.x_coord;
    difference.y_coord = y_coord - pVector.y_coord;
    difference.z_coord = z_coord - pVector.z_coord;
    return(difference);
  }

  // Pre:  This object is a defined Vector object representing <x, y, z>
  //       pVector is a defined Vector object representing <x1, y1, z1>
  // Post: RV = this representing <x - x1, y - y1, z - z1>
  Vector<T1, T2, T3> operator -= (const Vector<T1, T2, T3> & pVector) {
    x_coord -= pVector.x_coord;
    y_coord -= pVector.y_coord;
    z_coord -= pVector.z_coord;
    return(*this);
  }

  // Pre:  This object is a defined Vector object representing <x, y, z>
  //       pVector is a defined Vector object representing <x1, y1, z1>
  // Post: RV = a new Vector representing <x + x1, y + y1, z + z1>
  Vector<T1, T2, T3> operator + (float pValue) const {
    Vector<T1, T2, T3> sum;
    sum.x_coord = x_coord + pValue;
    sum.y_coord = y_coord + pValue;
    sum.z_coord = z_coord + pValue;
    return(sum);
  }

  // Pre:  This object is a defined Vector object representing <x, y, z>
  //       pVector is a defined Vector object representing <x1, y1, z1>
  // Post: RV = this representing <x + x1, y + y1, z + z1>
  Vector<T1, T2, T3> operator += (float pValue) {
    x_coord += pValue;
    y_coord += pValue;
    z_coord += pValue;
    return(*this);
  }

  // Pre:  This object is a defined Vector object representing <x, y, z>
  //       pVector is a defined Vector object representing <x1, y1, z1>
  // Post: RV = a new Vector representing <x - x1, y - y1, z - z1>
  Vector<T1, T2, T3> operator - (float pValue) const {
    Vector<T1, T2, T3> difference;
    difference.x_coord = x_coord - pValue;
    difference.y_coord = y_coord - pValue;
    difference.z_coord = z_coord - pValue;
    return(difference);
  }

  // Pre:  This object is a defined Vector object representing <x, y, z>
  //       pVector is a defined Vector object representing <x1, y1, z1>
  // Post: RV = this representing <x - x1, y - y1, z - z1>
  Vector<T1, T2, T3> operator -= (float pValue) {
    x_coord -= pValue;
    y_coord -= pValue;
    z_coord -= pValue;
    return(*this);
  }

  // Pre:  This object is a defined Vector object representing <x, y, z>
  //       multiplier is a float, c
  // Post: RV = a new Vector object representing <c*x, c*y, c*z>
  Vector<T1, T2, T3> operator * (float multiplier) {
    Vector<T1, T2, T3> product;
    product.x_coord = x_coord * multiplier;
    product.y_coord = y_coord * multiplier;
    product.z_coord = z_coord * multiplier;
    return(product);
  }

  // Pre:  This object is a defined Vector object representing <x, y, z>
  //       multiplier is a double, c
  // Post: RV = a new Vector object representing <c*x, c*y, c*z>
  Vector<T1, T2, T3> operator * (double multiplier) {
    Vector<T1, T2, T3> product;
    product.x_coord = x_coord * multiplier;
    product.y_coord = y_coord * multiplier;
    product.z_coord = z_coord * multiplier;
    return(product);
  }

  // Pre:  This object is a defined Vector object representing <x, y, z>
  //       multiplier is an integer, c
  // Post: RV = a new Vector object representing <c*x, c*y, c*z>
  Vector<T1, T2, T3> operator * (int multiplier) {
    Vector<T1, T2, T3> product;
    product.x_coord = x_coord * multiplier;
    product.y_coord = y_coord * multiplier;
    product.z_coord = z_coord * multiplier;
    return(product);
  }

  // Pre:  This object is a defined Vector object representing <x, y, z>
  //       multiplier is a float, c
  // Post: RV = this object representing <c*x, c*y, c*z>
  Vector<T1, T2, T3> operator *= (float multiplier) {
    x_coord *= multiplier;
    y_coord *= multiplier;
    z_coord *= multiplier;
    return(*this);
  }

  // Pre:  This object is a defined Vector object representing <x, y, z>
  //       multiplier is a double, c
  // Post: RV = this object representing <c*x, c*y, c*z>
  Vector<T1, T2, T3> operator *= (double multiplier) {
    x_coord *= multiplier;
    y_coord *= multiplier;
    z_coord *= multiplier;
    return(*this);
  }

  // Pre:  This object is a defined Vector object representing <x, y, z>
  //       divisor is a float, c
  // Post: RV = a new Vector object representing <x/c, y/c, z/c>
  Vector<T1, T2, T3> operator / (float divisor) {
    Vector<T1, T2, T3> quotient;
    quotient.x_coord = x_coord / divisor;
    quotient.y_coord = y_coord / divisor;
    quotient.z_coord = z_coord / divisor;
    return(quotient);
  }

  // Pre:  This object is a defined Vector object representing <x, y, z>
  //       divisor is a float, c
  // Post: RV = this object representing <x/c, y/c, z/c>
  Vector<T1, T2, T3> operator /= (float divisor) {
    x_coord /= divisor;
    y_coord /= divisor;
    z_coord /= divisor;
    return(*this);
  }

  // Pre:  This object is a defined Vector object representing <x, y, z>
  // Post: RV = the magnitude of this object
  float getMagnitude () const {
    float magnitude = sqrt(pow(x_coord, 2) + pow(y_coord, 2) + pow(z_coord, 2));
    return(magnitude);
  }

  // Pre:  This object is a defined Vector object representing <x, y, z>
  //       pVector is a Vector object representing <x1, y1, z1>
  // Post: RV = the dot producto of this and pVector
  float getDotProduct (const Vector<T1, T2, T3> & pVector) const {
    float product = 0;
    product += x_coord * pVector.x_coord;
    product += y_coord * pVector.y_coord;
    product += z_coord * pVector.z_coord;
    return(product);
  }

  // Pre:  This object is a defined Vector object representing <x, y, z>
  //       pVector is a Vector object representing <x1, y1, z1>
  // Post: RV = a new Vector representing the cross product of this and pVector
  Vector<T1, T2, T3> getCrossProduct (const Vector<T1, T2, T3> & pVector)
    const {
    Vector<T1, T2, T3> product;
    product.x_coord = ((y_coord * pVector.z_coord) -
		       (z_coord * pVector.y_coord));
    product.y_coord = (-1 * ((x_coord * pVector.z_coord) -
			    (z_coord * pVector.x_coord)));
    product.z_coord = ((x_coord * pVector.y_coord) -
		       (y_coord * pVector.x_coord));
    return(product);
  }

  // Pre:  stream is a defined writeable stream
  //       pVector is a defined Vector object representing <x, y, z>
  // Post: stream contains x, y, and z
  friend ostream & operator << (ostream & stream,
				const Vector<T1, T2, T3> & pVector) {
    stream << pVector.x_coord << ' ' << pVector.y_coord << ' '
       << pVector.z_coord;
    return(stream);
  }

  // Pre:  file is a defined ofstream object
  //       pVector is a defined Vector object
  // Post: RV = file, file contains data from pVector with a space
  //             between each value
  friend ofstream & operator << (ofstream & file,
                                 const Vector<T1, T2, T3> & pVector) {
      file << pVector.x_coord << ' ' << pVector.y_coord << ' '
           << pVector.z_coord;
      return(file);
  }

  // Pre:  file is a defined ifstream object
  //       pVector is a defined Vector object
  // Post: RV = file
  //       pVector contains data from file
  friend ifstream & operator >> (ifstream & file,
                                 Vector<T1, T2, T3> & pVector) {
    file >> pVector.x_coord;
    file >> pVector.y_coord;
    file >> pVector.z_coord;
    return(file);
  }
  
};

#endif
