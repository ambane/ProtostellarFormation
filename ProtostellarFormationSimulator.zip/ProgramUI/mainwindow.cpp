#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QInputDialog>
#include <QDir>
#include <QPainter>
#include <QPoint>
#include <sys/times.h>
#include <unistd.h>
#include <QtConcurrent/qtconcurrentrun.h>
#include "IOFile.h"
#include "ProcessTimestep.h"
#include "generatewindow.h"
#include "runwindow.h"
#include "animationwindow.h"
#include "progresswindow.h"
#include "animationconstants.h"
#include "ObjectArray.h"
#include "animationparticle.h"
#include "animationinput.h"
#include "helper.h"
using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    generate = new GenerateWindow();
    run = new RunWindow();
    animation = new AnimationWindow();
    progress = new ProgressWindow();
    connect(ui->GenerateFile, SIGNAL(clicked(bool)), this, SLOT(handleGenerateFileButton()));
    connect(ui->RunSimulation, SIGNAL(clicked(bool)), this, SLOT(handleRunSimulationButton()));
    connect(ui->WatchSimulation, SIGNAL(clicked(bool)), this, SLOT(handleWatchSimulationButton()));
}

MainWindow::~MainWindow()
{
    delete ui;
    delete generate;
    delete run;
    delete animation;
    delete progress;
}

void MainWindow::handleGenerateFileButton() {
    generate->show();
}

// Pre:
// Post:
void MainWindow::handleRunSimulationButton() {
    run->show();
}

// Pre:
// Post:
void MainWindow::handleWatchSimulationButton() {
    animation->resize(WINDOW_SIZE, WINDOW_SIZE);
    animation->show();
    AnimationInput * animationInput = new AnimationInput();
    animationInput->show();
    std::string file = animationInput->getPath();
    int numFiles = animationInput->getNumFiles();
    int numDivisions = animationInput->getClusterSize();
    bool ok = animationInput->getOK();
    if (ok) {
        animationInput->close();
        animation->runAnimation(file.data(), numFiles, numDivisions);
    }
    delete animation;
    animation = new AnimationWindow();
}
